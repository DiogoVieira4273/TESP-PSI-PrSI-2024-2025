package pt.ipleiria.estg.projeto.produtosginasio.modelo;

public class Cupao {
    private int id, desconto;
    private String codigo, dataFim;

    public Cupao(int id, String codigo, int desconto, String dataFim) {
        this.id = id;
        this.codigo = codigo;
        this.desconto = desconto;
        this.dataFim = dataFim;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getDesconto() {
        return desconto;
    }

    public void setDesconto(int desconto) {
        this.desconto = desconto;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getDataFim() {
        return dataFim;
    }

    public void setDataFim(String dataFim) {
        this.dataFim = dataFim;
    }
}
