package pt.ipleiria.estg.projeto.produtosginasio.modelo;

public class User {
    private int id, nif, telefone;
    private String username, password, email, morada;

    public User(int id, String username, String email, String password, int nif, String morada, int telefone) {
        this.id = id;
        this.username = username;
        this.email = email;
        this.password = password;
        this.nif = nif;
        this.morada = morada;
        this.telefone = telefone;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getNif() {
        return nif;
    }

    public void setNif(int nif) {
        this.nif = nif;
    }

    public String getMorada() {
        return morada;
    }

    public void setMorada(String morada) {
        this.morada = morada;
    }

    public int getTelefone() {
        return telefone;
    }

    public void setTelefone(int telefone) {
        this.telefone = telefone;
    }
}
