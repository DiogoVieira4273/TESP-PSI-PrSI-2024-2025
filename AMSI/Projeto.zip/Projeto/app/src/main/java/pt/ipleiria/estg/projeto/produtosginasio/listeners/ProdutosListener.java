package pt.ipleiria.estg.projeto.produtosginasio.listeners;

import android.view.View;

import java.util.ArrayList;

import pt.ipleiria.estg.projeto.produtosginasio.modelo.Produto;

public interface ProdutosListener {
    void onClick(View view);

    void onRefreshListaProdutos(ArrayList<Produto> listaProdutos);
}
