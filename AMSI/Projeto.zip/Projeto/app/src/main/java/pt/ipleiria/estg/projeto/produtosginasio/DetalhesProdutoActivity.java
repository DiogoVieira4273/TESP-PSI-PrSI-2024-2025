package pt.ipleiria.estg.projeto.produtosginasio;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import java.util.ArrayList;

import pt.ipleiria.estg.projeto.produtosginasio.listeners.ProdutoListener;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Produto;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.SingletonProdutosGinasio;

public class DetalhesProdutoActivity extends AppCompatActivity implements ProdutoListener {

    private TextView tvNome,tvPreco,tvDescricao;
    private ImageView imgProduto;
    private Produto produto;
    private int id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhes_produto);

        id = getIntent().getIntExtra(ListaProdutosFragment.ProdutoId,0);
        produto= SingletonProdutosGinasio.getInstance(getApplicationContext()).getProduto(id);
        SingletonProdutosGinasio.getInstance(getApplicationContext()).setProdutoListener(this);
        tvNome=findViewById(R.id.tvNome);
        tvPreco=findViewById(R.id.tvPreco);
        tvDescricao=findViewById(R.id.tvDescricao);
        imgProduto=findViewById(R.id.imgProduto);


        carregarProduto();
    }

    private void carregarProduto(){
        setTitle("Detalhes:" +produto.getNomeProduto());
        tvNome.setText(produto.getNomeProduto());
        tvPreco.setText(produto.getPreco()+"");
        tvDescricao.setText(produto.getDescricaoProduto());
        Glide.with(getApplicationContext())
                .load(produto.getImagem())
                .placeholder(R.drawable.ic_image_produto)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(imgProduto);
    }

    @Override
    public void onRefreshDetalhes(int operacaoDetalhes) {
        Intent intent = new Intent();
        setResult(RESULT_OK,intent);
        finish();
    }
}