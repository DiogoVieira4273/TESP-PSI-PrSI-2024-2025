package pt.ipleiria.estg.projeto.produtosginasio;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Locale;

import pt.ipleiria.estg.projeto.produtosginasio.adaptadores.ListaProdutosAdaptador;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.ProdutosListener;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Produto;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.SingletonProdutosGinasio;

public class ListaProdutosFragment extends Fragment implements ProdutosListener {
    private String IP, AUTH_KEY;
    SharedPreferences sharedPreferences;
    private ListaProdutosAdaptador adaptador;
    private ListView lvProdutos;
    public static final String ProdutoId = "ProdutoID";
    private ArrayList<Produto> produtos;
    private EditText etPesquisarProdutos;
    private ImageButton ivFiltro;

    public ListaProdutosFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_lista_produtos, container, false);
        setHasOptionsMenu(true);
        lvProdutos = view.findViewById(R.id.lvProdutos);
        etPesquisarProdutos = view.findViewById(R.id.etPesquisarProdutos);
        ivFiltro = view.findViewById(R.id.ivFiltro);

        sharedPreferences = getActivity().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);

        IP = sharedPreferences.getString("IP", "");
        AUTH_KEY = sharedPreferences.getString("auth_key", "");

        SingletonProdutosGinasio.getInstance(getContext()).setProdutosListener(this);
        SingletonProdutosGinasio.getInstance(getContext()).getAllProdutosAPI(getContext(), IP, AUTH_KEY);

        lvProdutos.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(getContext(), DetalhesProdutoActivity.class);
                intent.putExtra(ProdutoId, (int) l);
                startActivity(intent);
            }
        });

        // Configurar listener de clique para o botão de filtro
        ivFiltro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClickPesquisarProdutos();
            }
        });

        return view;
    }

    @Override
    public void onClick(View view) {
        Intent intent = new Intent(getContext(), DetalhesProdutoActivity.class);
        startActivity(intent);
    }

    @Override
    public void onRefreshListaProdutos(ArrayList<Produto> listaProdutos) {
        if (listaProdutos != null) {
            produtos = listaProdutos; // Atualizar a lista de produtos
            adaptador = new ListaProdutosAdaptador(getContext(), produtos);
            lvProdutos.setAdapter(adaptador);
        }
    }

    // Método chamado ao clicar no botão de filtro
    public void onClickPesquisarProdutos() {
        String query = etPesquisarProdutos.getText().toString();
        ArrayList<Produto> produtosFiltrados = filtrarProdutos(query);
        if (produtosFiltrados != null) {
            adaptador.setProdutos(produtosFiltrados);
            adaptador.notifyDataSetChanged();
        }
    }

    private ArrayList<Produto> filtrarProdutos(String query) {
        ArrayList<Produto> produtosFiltrados = new ArrayList<>();
        if (produtos != null) {
            for (Produto produto : produtos) {
                if (produto.getNomeProduto().toLowerCase(Locale.ROOT).contains(query.toLowerCase(Locale.ROOT))) {
                    produtosFiltrados.add(produto);
                }
            }
        }
        return produtosFiltrados;
    }
}