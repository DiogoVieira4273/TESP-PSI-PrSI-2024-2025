package pt.ipleiria.estg.projeto.produtosginasio;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

import pt.ipleiria.estg.projeto.produtosginasio.modelo.Produto;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.SingletonProdutosGinasio;

public class ListaProdutosFragment extends Fragment {
    private String IP, AUTH_KEY;
    SharedPreferences sharedPreferences;
    private ListView lvProdutos;
    private ArrayList<Produto> produtos;


    public ListaProdutosFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_lista_produtos, container, false);
        setHasOptionsMenu(true);
        lvProdutos = view.findViewById(R.id.lvProdutos);

        sharedPreferences = getActivity().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);

        IP = sharedPreferences.getString("IP", "");
        AUTH_KEY = sharedPreferences.getString("auth_key", "");

        //SingletonProdutosGinasio.getInstance(getContext()).setProdutosListener(getContext());
        SingletonProdutosGinasio.getInstance(getContext()).getAllProdutosAPI(getContext(), IP, AUTH_KEY);

        return view;
    }
}