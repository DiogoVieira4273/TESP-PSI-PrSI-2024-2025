package pt.ipleiria.estg.projeto.produtosginasio;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Map;

import pt.ipleiria.estg.projeto.produtosginasio.adaptadores.CarrinhoComprasAdaptador;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.CarrinhoComprasListener;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.LinhasCarrinho;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.SingletonProdutosGinasio;

public class CarrinhoDeComprasActivity extends AppCompatActivity implements CarrinhoComprasListener {
    private String IP, AUTH_KEY;
    SharedPreferences sharedPreferences;
    private ArrayList<LinhasCarrinho> linhasCarrinhos;
    private ListView lvProdutosCarrinho;
    private TextView tvTotal;
    private TextView tvTotalQuantidadeProdutosCarrinho;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_carrinho_de_compras);
        setTitle("Carrinho de Compras");

        lvProdutosCarrinho = findViewById(R.id.lvProdutosCarrinho);

        tvTotal = findViewById(R.id.tvTotal);
        tvTotalQuantidadeProdutosCarrinho = findViewById(R.id.tvTotalQuantidadeProdutosCarrinho);

        sharedPreferences = getApplication().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);

        IP = sharedPreferences.getString("IP", "");
        AUTH_KEY = sharedPreferences.getString("auth_key", "");

        atualizarvista();
    }

    @Override
    public void onRefreshLinhasCarrinho(ArrayList<LinhasCarrinho> linhasCarrinhos) {
        if (linhasCarrinhos != null) {
            this.linhasCarrinhos = linhasCarrinhos;
            CarrinhoComprasAdaptador adaptador = new CarrinhoComprasAdaptador(getApplicationContext(), linhasCarrinhos);
            adaptador.setListener(this);
            lvProdutosCarrinho.setAdapter(adaptador);
            ((BaseAdapter) lvProdutosCarrinho.getAdapter()).notifyDataSetChanged();
        }
    }

    @Override
    public void onProdutoAddQuantidade(int linhaCarrinho) {
        adicionarQuantidadeProdutoCarrinho(linhaCarrinho);

        atualizarvista();
    }

    @Override
    public void onProdutoRemoveQuantidade(int linhaCarrinho) {
        removerQuantidadeProdutoCarrinho(linhaCarrinho);

        atualizarvista();
    }

    @Override
    public void onProdutoRemovido(int linhaCarrinho) {
        removerProdutoCarrinho(linhaCarrinho);

        atualizarvista();
    }

    public void adicionarQuantidadeProdutoCarrinho(int linhaCarrinho) {
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String ip = sharedPreferences.getString("IP", "");
        String authKey = sharedPreferences.getString("auth_key", "");
        SingletonProdutosGinasio.getInstance(getApplicationContext()).adicionarQuantidadeProdutoCarrinhoAPI(getApplicationContext(), authKey, ip, linhaCarrinho);
    }

    public void removerQuantidadeProdutoCarrinho(int linhaCarrinho) {
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String ip = sharedPreferences.getString("IP", "");
        String authKey = sharedPreferences.getString("auth_key", "");
        SingletonProdutosGinasio.getInstance(getApplicationContext()).removerQuantidadeProdutoCarrinhoAPI(getApplicationContext(), authKey, ip, linhaCarrinho);
    }

    public void removerProdutoCarrinho(int linhaCarrinho) {
        SharedPreferences sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String ip = sharedPreferences.getString("IP", "");
        String authKey = sharedPreferences.getString("auth_key", "");
        SingletonProdutosGinasio.getInstance(getApplicationContext()).apagarProdutoCarrinhoAPI(getApplicationContext(), authKey, ip, linhaCarrinho);
    }

    private void atualizarvista() {
        SingletonProdutosGinasio.getInstance(getApplicationContext()).setCarrinhoComprasListener(this);
        SingletonProdutosGinasio.getInstance(getApplicationContext()).getLinhasCarrinhoAPI(getApplicationContext(), IP, AUTH_KEY);
        SingletonProdutosGinasio.getInstance(getApplicationContext()).getDetalhesCarrinhoAPI(getApplicationContext(), IP, AUTH_KEY);
    }

    private void carregarDadosDetalhes(Map<String, String> detalhesCarrinho) {
        tvTotalQuantidadeProdutosCarrinho.setText(detalhesCarrinho.get("quantidade_total"));
        tvTotal.setText(detalhesCarrinho.get("valorTotal") + "€");
    }

    @Override
    public void onDetalhesCarrinho(Map<String, String> detalhesCarrinho) {
        if (detalhesCarrinho != null) {
            carregarDadosDetalhes(detalhesCarrinho);
        } else {
            Toast.makeText(this, "Erro ao obter os detalhes do carrinho", Toast.LENGTH_LONG).show();
        }
    }

    public void onClickFinalizarCompra(View view) {
        Intent intent = new Intent(getApplicationContext(), FinalizarCompraActivity.class);
        startActivity(intent);
    }
}