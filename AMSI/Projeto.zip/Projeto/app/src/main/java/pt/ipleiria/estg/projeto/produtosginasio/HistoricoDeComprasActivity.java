package pt.ipleiria.estg.projeto.produtosginasio;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

import pt.ipleiria.estg.projeto.produtosginasio.adaptadores.HistoricoComprasAdaptador;
import pt.ipleiria.estg.projeto.produtosginasio.adaptadores.ListaProdutosAdaptador;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.ComprasListener;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Compra;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Produto;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.SingletonProdutosGinasio;

public class HistoricoDeComprasActivity extends AppCompatActivity implements ComprasListener {
    private String IP, AUTH_KEY;
    SharedPreferences sharedPreferences;
    private HistoricoComprasAdaptador adaptador;
    private ListView lvHistoricoCompras;
    private ArrayList<Compra> compras;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historico_de_compras);
        setTitle("Minhas Compras");

        lvHistoricoCompras = findViewById(R.id.lvHistoricoCompras);

        sharedPreferences = getApplication().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);

        IP = sharedPreferences.getString("IP", "");
        AUTH_KEY = sharedPreferences.getString("auth_key", "");

        SingletonProdutosGinasio.getInstance(getApplicationContext()).setComprasListener(this);
        SingletonProdutosGinasio.getInstance(getApplicationContext()).getAllComprasAPI(getApplicationContext(), IP, AUTH_KEY);

        lvHistoricoCompras.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                SingletonProdutosGinasio.getInstance(getApplicationContext()).downloadFaturaAPI(getApplicationContext(), IP, AUTH_KEY, (int) l);
            }
        });
    }

    @Override
    public void onRefreshCompras(ArrayList<Compra> listaCompras) {
        if (listaCompras != null) {
            lvHistoricoCompras.setAdapter(new HistoricoComprasAdaptador(getApplicationContext(), listaCompras));
        }
    }
}