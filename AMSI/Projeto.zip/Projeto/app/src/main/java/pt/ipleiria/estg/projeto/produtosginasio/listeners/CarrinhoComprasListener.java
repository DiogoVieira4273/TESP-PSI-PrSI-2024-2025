package pt.ipleiria.estg.projeto.produtosginasio.listeners;

import java.util.ArrayList;
import java.util.Map;

import pt.ipleiria.estg.projeto.produtosginasio.modelo.LinhasCarrinho;

public interface CarrinhoComprasListener {
    void onRefreshLinhasCarrinho(ArrayList<LinhasCarrinho> linhasCarrinhos);

    void onProdutoAddQuantidade(int linhaCarrinho);

    void onProdutoRemoveQuantidade(int linhaCarrinho);

    void onProdutoRemovido(int linhaCarrinho);

    void onDetalhesCarrinho(Map<String, String> detalhesCarrinho);
}
