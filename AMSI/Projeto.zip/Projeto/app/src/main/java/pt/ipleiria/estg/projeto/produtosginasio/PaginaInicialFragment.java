package pt.ipleiria.estg.projeto.produtosginasio;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ListView;

import java.util.ArrayList;

import pt.ipleiria.estg.projeto.produtosginasio.adaptadores.GrelhaProdutosAdaptador;
import pt.ipleiria.estg.projeto.produtosginasio.adaptadores.ListaCupoesAdaptador;
import pt.ipleiria.estg.projeto.produtosginasio.adaptadores.ListaProdutosAdaptador;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.PaginaInicialListener;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.ProdutosListener;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Cupao;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Produto;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.SingletonProdutosGinasio;

public class PaginaInicialFragment extends Fragment implements PaginaInicialListener {
    private ListView lvCupoesValidos;
    private GridView gvProdutos;
    private String IP;
    public static final String ProdutoId = "ProdutoID";
    private ListaCupoesAdaptador adaptadorCupoes;
    private GrelhaProdutosAdaptador adaptadorProdutos;
    private ArrayList<Cupao> cupoes;
    private ArrayList<Produto> produtos;
    SharedPreferences sharedPreferences;

    public PaginaInicialFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_pagina_inicial, container, false);
        setHasOptionsMenu(true);

        lvCupoesValidos = view.findViewById(R.id.lvCupoesValidos);
        gvProdutos = view.findViewById(R.id.gvProdutos);

        sharedPreferences = getActivity().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);

        IP = sharedPreferences.getString("IP", "");

        SingletonProdutosGinasio.getInstance(getContext()).setPaginaInicialListener(this);
        SingletonProdutosGinasio.getInstance(getContext()).getCupoesValidosAPI(getContext(), IP);
        SingletonProdutosGinasio.getInstance(getContext()).getUltimosProdutosAPI(getContext(), IP);

        gvProdutos.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(getContext(), DetalhesProdutoActivity.class);
                intent.putExtra(ProdutoId, (int) l);
                startActivity(intent);
            }
        });

        view.findViewById(R.id.btnVerMaisProdutos).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClickVerMaisProdutos(v);
            }
        });

        return view;
    }

    @Override
    public void onRefreshListaCupoesValidos(ArrayList<Cupao> listaCupoes) {
        if (listaCupoes != null) {
            cupoes = listaCupoes;
            adaptadorCupoes = new ListaCupoesAdaptador(getContext(), cupoes);
            lvCupoesValidos.setAdapter(adaptadorCupoes);
        }
    }

    @Override
    public void onRefreshListaProdutos(ArrayList<Produto> listaProdutos) {
        if (listaProdutos != null) {
            produtos = listaProdutos;
            adaptadorProdutos = new GrelhaProdutosAdaptador(getContext(), produtos);
            gvProdutos.setAdapter(adaptadorProdutos);
        }
    }

    public void onClickVerMaisProdutos(View view) {
        Intent intent = new Intent(getContext(), ProdutosActivity.class);
        startActivity(intent);
    }
}