package pt.ipleiria.estg.projeto.produtosginasio.listeners;

import java.util.ArrayList;

import pt.ipleiria.estg.projeto.produtosginasio.modelo.Compra;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Encomenda;

public interface EncomendasListener {
    void onRefreshEncomendas(ArrayList<Encomenda> listaEncomendas);
}
