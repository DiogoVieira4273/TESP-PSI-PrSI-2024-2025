package pt.ipleiria.estg.projeto.produtosginasio;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.ListView;

import java.util.ArrayList;

import pt.ipleiria.estg.projeto.produtosginasio.adaptadores.ListaProdutosAdaptador;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.ProdutosListener;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Produto;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.SingletonProdutosGinasio;

public class GrelhaProdutosFragment extends Fragment implements ProdutosListener {
    private String IP, AUTH_KEY;
    SharedPreferences sharedPreferences;
    private ListaProdutosAdaptador adaptador;
    private GridView gvProdutos;
    private ArrayList<Produto> produtos;

    public GrelhaProdutosFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_grelha_produtos, container, false);

        setHasOptionsMenu(true);
        gvProdutos = view.findViewById(R.id.gvProdutos);

        sharedPreferences = getActivity().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);

        IP = sharedPreferences.getString("IP", "");
        AUTH_KEY = sharedPreferences.getString("auth_key", "");

        SingletonProdutosGinasio.getInstance(getContext()).setProdutosListener(this);
        SingletonProdutosGinasio.getInstance(getContext()).getAllProdutosAPI(getContext(), IP, AUTH_KEY);

        return view;
    }

    @Override
    public void onRefreshListaProdutos(ArrayList<Produto> listaProdutos) {
        if (listaProdutos != null) {
            gvProdutos.setAdapter(new ListaProdutosAdaptador(getContext(), listaProdutos));
        }
    }
}