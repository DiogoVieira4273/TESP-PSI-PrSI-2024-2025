package pt.ipleiria.estg.projeto.produtosginasio.listeners;

import android.content.Context;

import java.util.ArrayList;

import pt.ipleiria.estg.projeto.produtosginasio.modelo.Avaliacao;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Compra;

public interface AvaliacaoListener {
    void onValidateRegister(final Context context);
}
