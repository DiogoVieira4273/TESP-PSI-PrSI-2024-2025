package pt.ipleiria.estg.projeto.produtosginasio.adaptadores;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import java.util.ArrayList;

import pt.ipleiria.estg.projeto.produtosginasio.R;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Avaliacao;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Produto;

public class AvaliacoesAdaptador extends BaseAdapter {
    private Context context;
    private LayoutInflater inflater;
    private ArrayList<Avaliacao> avaliacoes;

    public AvaliacoesAdaptador(Context context, ArrayList<Avaliacao> avaliacoes) {
        this.context = context;
        this.avaliacoes = avaliacoes;
    }

    @Override
    public int getCount() {
        return avaliacoes.size();
    }

    @Override
    public Object getItem(int i) {
        return avaliacoes.get(i);
    }

    @Override
    public long getItemId(int i) {
        return avaliacoes.get(i).getId();
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (inflater == null) {
            inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        if (view == null) {
            view = inflater.inflate(R.layout.item_avaliacao, null);
        }

        ViewHolderLista viewHolder = (ViewHolderLista) view.getTag();
        if (viewHolder == null) {
            viewHolder = new ViewHolderLista(view);
            view.setTag(viewHolder);
        }

        viewHolder.update(avaliacoes.get(i));

        return view;
    }

    private class ViewHolderLista {
        private ImageView imgAvaliacao;
        private TextView tvAvaliacao;

        public ViewHolderLista(View view) {
            tvAvaliacao = view.findViewById(R.id.tvAvaliacao);
            imgAvaliacao = view.findViewById(R.id.imgAvaliacao);
        }

        public void update(Avaliacao a) {
            tvAvaliacao.setText(a.getDescricao());
            Glide.with(context)
                    .load(R.drawable.ic_image_avaliacao)
                    .into(imgAvaliacao);
        }
    }
}
