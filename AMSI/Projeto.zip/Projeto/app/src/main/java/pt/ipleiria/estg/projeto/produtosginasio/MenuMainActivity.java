package pt.ipleiria.estg.projeto.produtosginasio;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.graphics.Insets;
import androidx.core.view.GravityCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.google.android.material.navigation.NavigationView;

import pt.ipleiria.estg.projeto.produtosginasio.modelo.FavoritoBdHelper;

public class MenuMainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private NavigationView navigationView;
    private DrawerLayout drawer;
    private FragmentManager fragmentManager;
    private String username, email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        drawer = findViewById(R.id.drawerLayout);
        navigationView = findViewById(R.id.navView);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this,
                drawer, toolbar, R.string.ndOpen, R.string.ndClose);
        toggle.syncState();
        drawer.addDrawerListener(toggle);

        carregarCabecalho();

        //chamar o listenner - neste caso fica à escuta de um clique
        navigationView.setNavigationItemSelectedListener(this);

        fragmentManager = getSupportFragmentManager();

        carregarFragmentoInicial();
    }

    private boolean carregarFragmentoInicial() {
        Menu menu = navigationView.getMenu();
        MenuItem item = menu.getItem(0);
        item.setChecked(true);
        return onNavigationItemSelected(item);
    }

    private void carregarCabecalho() {
        SharedPreferences sharedPrefs = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        username = sharedPrefs.getString("username", "");
        email = sharedPrefs.getString("email", "");

        View hView = navigationView.getHeaderView(0);
        TextView nav_tvUsername = hView.findViewById(R.id.tvUsername);
        TextView nav_tvEmail = hView.findViewById(R.id.tvEmail);

        if (username != null) {
            nav_tvUsername.setText(getString(R.string.txt_bem_vindo_menu) + username);
        } else {
            nav_tvUsername.setText(R.string.txt_username_vazio_menu);
        }

        if (email != null) {
            nav_tvEmail.setText(email);
        } else {
            nav_tvEmail.setText(R.string.txt_email_vazio_menu);
        }
    }

    //criar Listenner para o menu
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        Fragment fragment = null;

        SharedPreferences sharedPrefs = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String auth_key = sharedPrefs.getString("auth_key", "");

        if (item.getItemId() == R.id.navPaginaInicial) {
            //setTitle(item.getTitle());

            fragment = new PaginaInicialFragment();

        } else if (item.getItemId() == R.id.navProdutos) {
            Intent intent = new Intent(this, ProdutosActivity.class);
            startActivity(intent);

        } else if (item.getItemId() == R.id.navCarrinhoCompras) {
            if (!auth_key.isEmpty()) {
                Intent intent = new Intent(this, CarrinhoDeComprasActivity.class);
                startActivity(intent);
            } else {
                Toast.makeText(getApplicationContext(), "Não tem sessão iniciada.", Toast.LENGTH_LONG).show();
            }

        } else if (item.getItemId() == R.id.navFavoritos) {
            if (!auth_key.isEmpty()) {
                Intent intent = new Intent(this, FavoritosActivity.class);
                startActivity(intent);
            } else {
                Toast.makeText(getApplicationContext(), "Não tem sessão iniciada.", Toast.LENGTH_LONG).show();
            }

        } else if (item.getItemId() == R.id.navPerfil) {
            if (!auth_key.isEmpty()) {
                Intent intent = new Intent(this, PerfilActivity.class);
                startActivity(intent);
            } else {
                Toast.makeText(getApplicationContext(), "Não tem sessão iniciada.", Toast.LENGTH_LONG).show();
            }

        } else if (item.getItemId() == R.id.navHistoricoCompras) {
            if (!auth_key.isEmpty()) {
                Intent intent = new Intent(this, HistoricoDeComprasActivity.class);
                startActivity(intent);
            } else {
                Toast.makeText(getApplicationContext(), "Não tem sessão iniciada.", Toast.LENGTH_LONG).show();
            }

        } else if (item.getItemId() == R.id.navEncomendas) {
            if (!auth_key.isEmpty()) {
                Intent intent = new Intent(this, HistoricoDeEncomendasActivity.class);
                startActivity(intent);
            } else {
                Toast.makeText(getApplicationContext(), "Não tem sessão iniciada.", Toast.LENGTH_LONG).show();
            }

        } else if (item.getItemId() == R.id.navAvaliacoes) {
            if (!auth_key.isEmpty()) {
                Intent intent = new Intent(this, AvaliacoesActivity.class);
                startActivity(intent);
            } else {
                Toast.makeText(getApplicationContext(), "Não tem sessão iniciada.", Toast.LENGTH_LONG).show();
            }

        } else if (item.getItemId() == R.id.navTerminarSessao) {
            FavoritoBdHelper dbHelper = new FavoritoBdHelper(this);
            dbHelper.removerAllFavoritoBD();

            SharedPreferences sharedPreferences = getApplication().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.remove("auth_key");
            editor.remove("username");
            editor.remove("email");
            editor.remove("profile_id");
            editor.apply();

            Intent intent = new Intent(this, LoginActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();

        }

        if (fragment != null) {
            fragmentManager.beginTransaction().replace(R.id.contentFragment, fragment).commit();
        }

        drawer.closeDrawer(GravityCompat.START);

        return true;
    }
}