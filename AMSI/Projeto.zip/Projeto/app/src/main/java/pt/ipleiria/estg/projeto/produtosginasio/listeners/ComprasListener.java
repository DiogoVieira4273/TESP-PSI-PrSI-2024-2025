package pt.ipleiria.estg.projeto.produtosginasio.listeners;

import java.util.ArrayList;

import pt.ipleiria.estg.projeto.produtosginasio.modelo.Compra;

public interface ComprasListener {
    void onRefreshCompras(ArrayList<Compra> listaCompras);
}