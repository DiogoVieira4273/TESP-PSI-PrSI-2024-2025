package pt.ipleiria.estg.projeto.produtosginasio.adaptadores;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import pt.ipleiria.estg.projeto.produtosginasio.R;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Compra;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Encomenda;

public class HistoricoEncomendasAdaptador extends BaseAdapter {
    private Context context;
    private LayoutInflater inflater;
    private ArrayList<Encomenda> encomendas;

    public HistoricoEncomendasAdaptador(Context context, ArrayList<Encomenda> encomendas) {
        this.context = context;
        this.encomendas = encomendas;
    }

    @Override
    public int getCount() {
        return encomendas.size();
    }

    @Override
    public Object getItem(int i) {
        return encomendas.get(i);
    }

    @Override
    public long getItemId(int i) {
        return encomendas.get(i).getId();
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (inflater == null) {
            inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        if (view == null) {
            view = inflater.inflate(R.layout.item_historico_encomendas, null);
        }

        //para ir buscar um livro pela primeira vez
        //quando vai pela segunda vez, este pedaço de código não funciona
        HistoricoEncomendasAdaptador.ViewHolderLista viewHolder = (HistoricoEncomendasAdaptador.ViewHolderLista) view.getTag();
        if (viewHolder == null) {
            viewHolder = new HistoricoEncomendasAdaptador.ViewHolderLista(view);
            view.setTag(viewHolder);
        }

        //apresentar os produto(s) na vista
        viewHolder.update(encomendas.get(i));

        return view;
    }

    private class ViewHolderLista {
        private TextView tvEncomendaID, tvData, tvHora;
        private ImageView imgCapa;

        public ViewHolderLista(View view) {
            tvEncomendaID = view.findViewById(R.id.tvEncomendaID);
            tvData = view.findViewById(R.id.tvData);
            tvHora = view.findViewById(R.id.tvHora);
            imgCapa = view.findViewById(R.id.imgCapa);
        }

        public void update(Encomenda e) {
            tvEncomendaID.setText("Encomenda Nº " + e.getId() + "");
            tvData.setText("Data: " + e.getData());
            tvHora.setText("Hora: " + e.getHora());
            imgCapa.setImageResource(R.drawable.ic_image_truck_encomenda);
        }
    }
}
