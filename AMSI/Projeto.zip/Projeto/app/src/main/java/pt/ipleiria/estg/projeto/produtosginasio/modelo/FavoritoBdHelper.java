package pt.ipleiria.estg.projeto.produtosginasio.modelo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class FavoritoBdHelper extends SQLiteOpenHelper {
    private static final String DB_NAME="dbfavoritos";
    private static final String FAVORITOS="favoritos";
    private static final String ID="id",PRODUTO_ID="produto_id",PROFILE_ID="profile_id",NOMEPRODUTO="nomeProduto",PRECO="preco",IMAGEM="imagem";
    private final SQLiteDatabase db;

    public FavoritoBdHelper(@Nullable Context context) {
        super(context,DB_NAME,null,1);
        db = getWritableDatabase();
    }


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String sqlTabelaFavorito = "CREATE TABLE "+FAVORITOS+" ("+ ID +" INTEGER PRIMARY KEY, " +
                PRODUTO_ID +" INTEGER NOT NULL, "+
                PROFILE_ID +" INTEGER NOT NULL, " +
                NOMEPRODUTO +" TEXT NOT NULL, " +
                PRECO +" DOUBLE NOT NULL, " +
                IMAGEM +" TEXT); " ;
        sqLiteDatabase.execSQL(sqlTabelaFavorito);
    }


    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        String sqlDelTableFavorito=" DROP TABLE IF EXISTS "+FAVORITOS;
        sqLiteDatabase.execSQL(sqlDelTableFavorito);
        this.onCreate(sqLiteDatabase);
    }

    //Métodos CRUD
    public ArrayList<Favorito> getAllFavoritosBD() {
        ArrayList<Favorito> favoritos = new ArrayList<>();
        Cursor cursor = this.db.query(FAVORITOS, new String[] {ID,PRODUTO_ID,PROFILE_ID,NOMEPRODUTO,PRECO,IMAGEM},null,null,null,null,null);
        if (cursor.moveToFirst()){
            do{
                Favorito auxFavorito=new Favorito(cursor.getInt(0),cursor.getInt(1),cursor.getInt(2),cursor.getString(3),cursor.getFloat(4),cursor.getString(5));
                favoritos.add(auxFavorito);
            }while (cursor.moveToNext());
            cursor.close();
        }
        return favoritos;
    }

    public Favorito adicionarFavoritoBD(Favorito f){
        ContentValues values = new ContentValues();
        values.put(ID,f.getId());
        values.put(PRODUTO_ID,f.getProduto_id());
        values.put(PROFILE_ID,f.getProfile_id());
        values.put(NOMEPRODUTO,f.getNomeProduto());
        values.put(PRECO,f.getPreco());
        values.put(IMAGEM,f.getImagem());

        long id = db.insert(FAVORITOS, null,values);

        if(id > -1){
            f.setId((int) id);
            return f;
        }
        return null;
    }

    public boolean removerFavoritoBD(int idFavorito){
        int numLinhasDel=this.db.delete(FAVORITOS,ID+"=?",new String[]{idFavorito+""});
        return numLinhasDel==1;
    }

    public void removerAllFavoritoBD(){
        this.db.delete(FAVORITOS,null,null);
    }
}