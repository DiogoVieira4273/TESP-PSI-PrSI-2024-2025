package pt.ipleiria.estg.projeto.produtosginasio;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Map;

import pt.ipleiria.estg.projeto.produtosginasio.adaptadores.MetodoEntregaAdaptador;
import pt.ipleiria.estg.projeto.produtosginasio.adaptadores.MetodoPagamentoAdaptador;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.FinalizarCompraListener;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.MetodoEntrega;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.MetodoPagamento;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.SingletonProdutosGinasio;

public class FinalizarCompraActivity extends AppCompatActivity implements FinalizarCompraListener {
    private Spinner metodosdepagamento, metodosdeentrega;
    private TextView tvTotal;
    private EditText etEmail, etNIF, etMorada, etTelefone;
    private String IP, AUTH_KEY;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finalizar_compra);
        setTitle("Finalizar Compra");

        metodosdepagamento = findViewById(R.id.metodosdepagamento);
        metodosdeentrega = findViewById(R.id.metodosdeentrega);

        etEmail = findViewById(R.id.etEmail);
        etNIF = findViewById(R.id.etNIF);
        etMorada = findViewById(R.id.etMorada);
        etTelefone = findViewById(R.id.etTelefone);

        tvTotal = findViewById(R.id.tvTotal);

        sharedPreferences = getApplication().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);

        IP = sharedPreferences.getString("IP", "");
        AUTH_KEY = sharedPreferences.getString("auth_key", "");

        SingletonProdutosGinasio.getInstance(getApplicationContext()).setFinalizarCompraListener(this);
        SingletonProdutosGinasio.getInstance(getApplicationContext()).getAllMetodosPagamentosAPI(getApplicationContext(), IP, AUTH_KEY);
        SingletonProdutosGinasio.getInstance(getApplicationContext()).getAllMetodosEntregasAPI(getApplicationContext(), IP, AUTH_KEY);
        SingletonProdutosGinasio.getInstance(getApplicationContext()).getDadosclienteAPI(getApplicationContext(), IP, AUTH_KEY);

        atualizarvista();
    }

    @Override
    public void onRefreshListaMetodosPagamento(ArrayList<MetodoPagamento> metodoPagamentos) {
        if (metodoPagamentos != null) {
            MetodoPagamentoAdaptador adaptador = new MetodoPagamentoAdaptador(this, metodoPagamentos);
            metodosdepagamento.setAdapter(adaptador);
        }
    }

    @Override
    public void onRefreshListaMetodosEntrega(ArrayList<MetodoEntrega> metodoEntregas) {
        if (metodoEntregas != null) {
            MetodoEntregaAdaptador adaptador = new MetodoEntregaAdaptador(this, metodoEntregas);
            metodosdeentrega.setAdapter(adaptador);
        }
    }

    private void carregarDadosUser(Map<String, String> dadosCliente) {
        etEmail.setText(dadosCliente.get("email"));
        etNIF.setText(dadosCliente.get("nif"));
        etMorada.setText(dadosCliente.get("morada"));
        etTelefone.setText(dadosCliente.get("telefone"));
    }

    @Override
    public void onDadoscliente(Map<String, String> dadosCliente) {
        if (dadosCliente != null) {
            carregarDadosUser(dadosCliente);
        } else {
            Toast.makeText(this, "Erro ao obter os dados cliente", Toast.LENGTH_LONG).show();
        }
    }

    private void atualizarvista() {
        SingletonProdutosGinasio.getInstance(getApplicationContext()).getDetalhesFinalizarCompraAPI(getApplicationContext(), IP, AUTH_KEY);
    }

    private void carregarDadosDetalhes(Map<String, String> detalhesFinalizarCompra) {
        tvTotal.setText(detalhesFinalizarCompra.get("valorTotal") + "€");
    }

    @Override
    public void onDetalhesFinalizarCompra(Map<String, String> detalhesFinalizarCompra) {
        if (detalhesFinalizarCompra != null) {
            carregarDadosDetalhes(detalhesFinalizarCompra);
        } else {
            Toast.makeText(this, "Erro ao obter o valor total da compra", Toast.LENGTH_LONG).show();
        }
    }
}