package pt.ipleiria.estg.projeto.produtosginasio;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Map;

import pt.ipleiria.estg.projeto.produtosginasio.adaptadores.MetodoEntregaAdaptador;
import pt.ipleiria.estg.projeto.produtosginasio.adaptadores.MetodoPagamentoAdaptador;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.FinalizarCompraListener;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.MetodoEntrega;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.MetodoPagamento;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.SingletonProdutosGinasio;

public class FinalizarCompraActivity extends AppCompatActivity implements FinalizarCompraListener {
    private Spinner metodosdepagamento, metodosdeentrega;
    private TextView tvDesconto, tvCustoEnvio, tvValorPoupado, tvSubtotal, tvTotal;
    private EditText etCupao, etEmail, etNIF, etMorada, etTelefone;
    private String IP, AUTH_KEY, codigocupao = "";
    private int idMetodoPagamentoSelecionado, idMetodoEntregaSelecionado;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finalizar_compra);

        setTitle("Finalizar Compra");

        metodosdepagamento = findViewById(R.id.metodosdepagamento);
        metodosdeentrega = findViewById(R.id.metodosdeentrega);

        etEmail = findViewById(R.id.etEmail);
        etNIF = findViewById(R.id.etNIF);
        etMorada = findViewById(R.id.etMorada);
        etTelefone = findViewById(R.id.etTelefone);

        tvDesconto = findViewById(R.id.tvDesconto);
        tvCustoEnvio = findViewById(R.id.tvCustoEnvio);
        tvValorPoupado = findViewById(R.id.tvValorPoupado);
        tvSubtotal = findViewById(R.id.tvSubtotal);
        tvTotal = findViewById(R.id.tvTotal);

        sharedPreferences = getApplication().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);

        IP = sharedPreferences.getString("IP", "");
        AUTH_KEY = sharedPreferences.getString("auth_key", "");

        SingletonProdutosGinasio.getInstance(getApplicationContext()).setFinalizarCompraListener(this);
        SingletonProdutosGinasio.getInstance(getApplicationContext()).getAllMetodosPagamentosAPI(getApplicationContext(), IP, AUTH_KEY);
        SingletonProdutosGinasio.getInstance(getApplicationContext()).getAllMetodosEntregasAPI(getApplicationContext(), IP, AUTH_KEY);
        SingletonProdutosGinasio.getInstance(getApplicationContext()).getDadosclienteAPI(getApplicationContext(), IP, AUTH_KEY);

        //configurar listener no Spinner para obter o ID do método de pagamento selecionado
        metodosdepagamento.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                MetodoPagamento metodoSelecionado = (MetodoPagamento) parent.getItemAtPosition(position);
                idMetodoPagamentoSelecionado = metodoSelecionado.getId();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Nada selecionado
            }
        });

        //configurar listener no Spinner para obter o ID do método de entrega selecionado
        metodosdeentrega.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                MetodoEntrega metodoSelecionado = (MetodoEntrega) parent.getItemAtPosition(position);
                idMetodoEntregaSelecionado = metodoSelecionado.getId();
                atualizarvista(idMetodoEntregaSelecionado, codigocupao);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Nada selecionado
            }
        });

        atualizarvista(idMetodoEntregaSelecionado, codigocupao);
    }

    @Override
    public void onRefreshListaMetodosPagamento(ArrayList<MetodoPagamento> metodoPagamentos) {
        if (metodoPagamentos != null) {
            MetodoPagamentoAdaptador adaptador = new MetodoPagamentoAdaptador(this, metodoPagamentos);
            metodosdepagamento.setAdapter(adaptador);
        }
    }

    @Override
    public void onRefreshListaMetodosEntrega(ArrayList<MetodoEntrega> metodoEntregas) {
        if (metodoEntregas != null) {
            MetodoEntregaAdaptador adaptador = new MetodoEntregaAdaptador(this, metodoEntregas);
            metodosdeentrega.setAdapter(adaptador);
        }
    }

    private void carregarDadosUser(Map<String, String> dadosCliente) {
        etEmail.setText(dadosCliente.get("email"));
        etNIF.setText(dadosCliente.get("nif"));
        etMorada.setText(dadosCliente.get("morada"));
        etTelefone.setText(dadosCliente.get("telefone"));
    }

    @Override
    public void onDadoscliente(Map<String, String> dadosCliente) {
        if (dadosCliente != null) {
            carregarDadosUser(dadosCliente);
        } else {
            Toast.makeText(this, "Erro ao obter os dados cliente", Toast.LENGTH_LONG).show();
        }
    }

    private void atualizarvista(int metodoEntregaSelecionado, String codigo) {
        SingletonProdutosGinasio.getInstance(getApplicationContext()).getDetalhesFinalizarCompraAPI(getApplicationContext(), IP, AUTH_KEY, metodoEntregaSelecionado, codigo);
    }

    private void carregarDadosDetalhes(Map<String, String> detalhesFinalizarCompra) {
        tvDesconto.setText(detalhesFinalizarCompra.get("desconto") + "%");
        tvCustoEnvio.setText(detalhesFinalizarCompra.get("custoEnvio") + "€");
        tvValorPoupado.setText(detalhesFinalizarCompra.get("valorPoupado") + "€");
        tvSubtotal.setText(detalhesFinalizarCompra.get("subtotal") + "€");
        tvTotal.setText(detalhesFinalizarCompra.get("valorTotal") + "€");
    }

    @Override
    public void onDetalhesFinalizarCompra(Map<String, String> detalhesFinalizarCompra) {
        if (detalhesFinalizarCompra != null) {
            carregarDadosDetalhes(detalhesFinalizarCompra);
        } else {
            Toast.makeText(this, "Erro ao obter o valor total da compra", Toast.LENGTH_LONG).show();
        }
    }

    public void onclickAplicarCupao(View view) {
        etCupao = findViewById(R.id.etCupao);
        String codigo = etCupao.getText().toString();

        SingletonProdutosGinasio.getInstance(getApplicationContext()).aplicarCupaoDescontoAPI(getApplicationContext(), AUTH_KEY, IP, codigo, idMetodoEntregaSelecionado);
    }

    @Override
    public void onCodigoCupao(Map<String, String> codigoCupao) {
        if (codigoCupao != null) {
            codigocupao = codigoCupao.get("codigoCupao");
        } else {
            Toast.makeText(this, "Erro ao obter o valor total da compra", Toast.LENGTH_LONG).show();
        }
    }

    public void onClickConcluirCompra(View view) {
        if (metodosdepagamento.toString().isEmpty()) {
            Toast.makeText(this, "Opção de pagamento não selecionada", Toast.LENGTH_LONG).show();
            return;
        }
        if (metodosdeentrega.toString().isEmpty()) {
            Toast.makeText(this, "Opção de entrega não selecionada", Toast.LENGTH_LONG).show();
            return;
        }
        if (etEmail.getText().toString().isEmpty()) {
            Toast.makeText(this, "Campo do email não preenchido", Toast.LENGTH_LONG).show();
            return;
        }
        if (etMorada.getText().toString().isEmpty()) {
            Toast.makeText(this, "Campo da morada não preenchido", Toast.LENGTH_LONG).show();
            return;
        }
        if (etTelefone.getText().toString().isEmpty()) {
            Toast.makeText(this, "Campo do telefone não preenchido", Toast.LENGTH_LONG).show();
            return;
        }

        SingletonProdutosGinasio.getInstance(getApplicationContext()).concluirCompraAPI(getApplicationContext(), IP, AUTH_KEY, idMetodoPagamentoSelecionado, idMetodoEntregaSelecionado, codigocupao, etEmail.getText().toString(), Integer.parseInt(etNIF.getText().toString()), etMorada.getText().toString(), Integer.parseInt(etTelefone.getText().toString()));

        // Fechar a atividade atual para voltar ao Carrinho de Compras
        finish();

    }
}