package pt.ipleiria.estg.projeto.produtosginasio.adaptadores;

import static java.security.AccessController.getContext;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import java.util.ArrayList;
import java.util.Map;

import pt.ipleiria.estg.projeto.produtosginasio.ListaFavoritosFragment;
import pt.ipleiria.estg.projeto.produtosginasio.R;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Favorito;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Produto;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.SingletonProdutosGinasio;

public class ListaFavoritosAdaptador extends BaseAdapter {
    private Context context;
    private LayoutInflater inflater;
    private ArrayList<Favorito> favoritos;

    public ListaFavoritosAdaptador(Context context, ArrayList<Favorito> favoritos) {
        this.context = context;
        this.favoritos = favoritos;
    }
    @Override
    public int getCount() {
        return favoritos.size();
    }

    @Override
    public Object getItem(int i) {
        return favoritos.get(i);
    }

    @Override
    public long getItemId(int i) {
        return favoritos.get(i).getId();
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (inflater == null) {
            inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        // Verifica se a view já foi criada ou precisa ser inflada
        if (view == null) {
            view = inflater.inflate(R.layout.item_lista_favoritos, viewGroup, false);
        }

        ViewHolderLista viewHolder = (ViewHolderLista) view.getTag();
        if (viewHolder == null) {
            viewHolder = new ViewHolderLista(view);
            view.setTag(viewHolder);
        }

        // Atualiza os dados da view com as informações do favorito
        Favorito favorito = favoritos.get(i);
        viewHolder.update(favorito, i);


        return view;
    }

    private class ViewHolderLista {
        private ImageView imgProduto;
        private TextView tvNomeProduto, tvPreco;
        private ImageButton imgRemoveFavoritos;

        public ViewHolderLista(View view) {
            tvNomeProduto = view.findViewById(R.id.tvNomeProduto);
            tvPreco = view.findViewById(R.id.tvPreco);
            imgProduto = view.findViewById(R.id.imgProduto);
            imgRemoveFavoritos = view.findViewById(R.id.imgRemoveFavoritos);
        }

        public void update(Favorito favorito, int position) {
            tvNomeProduto.setText(favorito.getNomeProduto());
            tvPreco.setText(String.format("€ %.2f", favorito.getPreco()));
            Glide.with(context)
                    .load(favorito.getImagem())
                    .placeholder(R.drawable.ic_image_produto)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(imgProduto);

            // Configura o botão para remover o favorito
            imgRemoveFavoritos.setOnClickListener(v -> {
                SharedPreferences sharedPreferences = context.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
                String IP = sharedPreferences.getString("IP", "");
                String AUTH_KEY = sharedPreferences.getString("auth_key", "");

                if (IP.isEmpty() || AUTH_KEY.isEmpty()) {
                    Toast.makeText(context, "Configurações inválidas (IP ou Auth Key faltando)", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Remove o favorito da API
                int favoritoId = favorito.getId();
                SingletonProdutosGinasio.getInstance(context).removerFavoritoAPI(context, AUTH_KEY, IP, favoritoId);

                // Remove o favorito da lista local e atualiza o adaptador
                favoritos.remove(position);
                notifyDataSetChanged();

                Toast.makeText(context, "Favorito removido com sucesso!", Toast.LENGTH_SHORT).show();
            });
        }

    }
}
