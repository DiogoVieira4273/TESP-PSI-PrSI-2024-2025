package pt.ipleiria.estg.projeto.produtosginasio;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

import pt.ipleiria.estg.projeto.produtosginasio.adaptadores.GrelhaFavoritosAdaptador;
import pt.ipleiria.estg.projeto.produtosginasio.adaptadores.ListaFavoritosAdaptador;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.FavoritosListener;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Favorito;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.SingletonProdutosGinasio;

public class GrelhaFavoritosFragment extends Fragment implements FavoritosListener {
    private String IP, AUTH_KEY;
    SharedPreferences sharedPreferences;
    private GridView gvFavoritos;
    private ArrayList<Favorito> favoritos;
    public static final String ProdutoID= "ProdutoID";
    public static final int ADD=100,DELETE=200;

    public GrelhaFavoritosFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_grelha_favoritos, container, false);
        setHasOptionsMenu(true);

        gvFavoritos=view.findViewById(R.id.gvFavoritos);
        sharedPreferences = getActivity().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);

        IP = sharedPreferences.getString("IP", "");
        AUTH_KEY = sharedPreferences.getString("auth_key", "");
        SingletonProdutosGinasio.getInstance(getContext()).setFavoritosListener(this);
        SingletonProdutosGinasio.getInstance(getContext()).getAllFavoritosApi(getContext(), IP, AUTH_KEY);

        return view;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            // Atualiza a lista de favoritos após adicionar um novo favorito
            SingletonProdutosGinasio.getInstance(getContext()).getAllFavoritosApi(getContext(), IP, AUTH_KEY);

            if (requestCode == ADD) {
                // Se a requisição foi para adicionar favorito, mostra a mensagem
                Toast.makeText(getContext(), "Favorito adicionado com sucesso", Toast.LENGTH_LONG).show();
            }
        }
    }

    public void onApagarFavorito(int favoritoId) {
        removerFavorito(favoritoId);
        atualizarVista();
    }

    public void removerFavorito(int favoritoId) {
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        String ip = sharedPreferences.getString("IP", "");
        String authKey = sharedPreferences.getString("auth_key", "");

        SingletonProdutosGinasio.getInstance(getContext())
                .removerFavoritoAPI(getContext(), authKey, ip, favoritoId);
    }

    public void atualizarVista() {
        SingletonProdutosGinasio.getInstance(getContext()).getAllFavoritosApi(getContext(), IP, AUTH_KEY);
    }

    @Override
    public void onRefresListaFavoritos(ArrayList<Favorito> listaFavoritos) {
        if(listaFavoritos != null){
            gvFavoritos.setAdapter(new GrelhaFavoritosAdaptador(getContext(),listaFavoritos));
        }else{
            Toast.makeText(getContext(),"Nenhum favorito",Toast.LENGTH_LONG).show();
        }
    }
}