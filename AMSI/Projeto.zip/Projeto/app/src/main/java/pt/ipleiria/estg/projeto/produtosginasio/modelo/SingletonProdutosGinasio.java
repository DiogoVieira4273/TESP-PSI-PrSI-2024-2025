package pt.ipleiria.estg.projeto.produtosginasio.modelo;

import android.content.Context;
import android.content.SharedPreferences;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import pt.ipleiria.estg.projeto.produtosginasio.listeners.LoginListener;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.ProdutosListener;
import pt.ipleiria.estg.projeto.produtosginasio.utils.GinasioJsonParser;

public class SingletonProdutosGinasio {
    private static SingletonProdutosGinasio instance = null;
    private static RequestQueue volleyQueue = null;
    private ArrayList<Produto> produtos;
    private LoginListener loginListener;
    private ProdutosListener produtosListener;

    public static synchronized SingletonProdutosGinasio getInstance(Context context) {
        //se tiver, cria um sigleton
        if (instance == null) {
            instance = new SingletonProdutosGinasio(context);
            //iniciar a pilha de pedidos para a API (pedidos assíncronos)
            volleyQueue = Volley.newRequestQueue(context);
        }
        //senão devolve o que tem
        return instance;
    }

    private SingletonProdutosGinasio(Context context) {
        produtos = new ArrayList<>();
        //livrosBD = new LivroBDHelper(context);
    }

    public void setLoginListener(LoginListener loginListener) {
        this.loginListener = loginListener;
    }

    public void setProdutosListener(ProdutosListener produtosListener) {
        this.produtosListener = produtosListener;
    }

    public void loginAPI(final Context context, final String IP, String username, String password) {
        final String mUrlAPILogin = "http://" + IP + "/produtosginasio/backend/web/api/login/login";
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            StringRequest reqLogin = new StringRequest(Request.Method.POST, mUrlAPILogin, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    System.out.println("auth_key: " + response);
                    String auth_key = GinasioJsonParser.parserJsonLogin(response);
                    //TODO: atualizar a vista
                    if (loginListener != null) {
                        loginListener.onValidateLogin(context, auth_key);
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    System.out.println(error);
                    Toast.makeText(context, error.getMessage(), Toast.LENGTH_LONG).show();
                }
            }) {
                @Override
                public String getBodyContentType() {
                    return "application/x-www-form-urlencoded; charset=UTF-8";
                }

                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("username", username);
                    params.put("password", password);
                    return params;
                }


            };
            volleyQueue.add(reqLogin);
        }
    }

    public void getAllProdutosAPI(final Context context, String IP, String AUTH_KEY) {
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            final String mUrlAPIProdutos = "http://" + IP + "/produtosginasio/backend/web/api/produto/produtos";
            JsonArrayRequest reqSelect = new JsonArrayRequest(Request.Method.GET, mUrlAPIProdutos, null, new Response.Listener<JSONArray>() {
                @Override
                public void onResponse(JSONArray response) {
                    produtos = GinasioJsonParser.parserJsonProdutos(response);

                    //TODO: atualizar a vista
                    if (produtosListener != null) {
                        produtosListener.onRefreshListaLivros(produtos);
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    //
                }
            }) {
                @Override
                public Map<String, String> getHeaders() {
                    Map<String, String> headers = new HashMap<>();
                    headers.put("Authorization", AUTH_KEY);
                    return headers;
                }
            };
            volleyQueue.add(reqSelect);
        }
    }
}
