package pt.ipleiria.estg.projeto.produtosginasio.modelo;

import android.app.Activity;
import android.content.Context;
import android.os.Environment;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NetworkResponse;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import pt.ipleiria.estg.projeto.produtosginasio.ListaFavoritosFragment;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.AvaliacaoListener;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.CarrinhoComprasListener;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.ComprasListener;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.DetalhesEncomendaListener;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.EncomendasListener;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.FavoritoListener;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.FavoritosListener;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.FinalizarCompraListener;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.LoginListener;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.ProdutoListener;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.ProdutosListener;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.RegistoListener;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.UserProfileListener;
import pt.ipleiria.estg.projeto.produtosginasio.utils.GinasioJsonParser;

public class SingletonProdutosGinasio {
    private static SingletonProdutosGinasio instance = null;
    private static RequestQueue volleyQueue = null;
    private ArrayList<Produto> produtos;
    private ArrayList<LinhasCarrinho> linhasCarrinho;
    private ArrayList<Compra> compras;
    private ArrayList<Encomenda> encomendas;
    private LoginListener loginListener;
    private UserProfileListener UserProfileListener;
    private RegistoListener registoListener;
    private AvaliacaoListener avaliacaoListener;
    private ArrayList<Favorito> favoritos;
    private FavoritoBdHelper favoritosBD;
    private ArrayList<MetodoPagamento> metodoPagamentos;
    private FavoritosListener favoritosListener;
    private FavoritoListener favoritoListener;
    private ProdutosListener produtosListener;
    private ProdutoListener produtoListener;
    private CarrinhoComprasListener carrinhoComprasListener;
    private ComprasListener comprasListener;
    private FinalizarCompraListener finalizarCompraListener;
    private EncomendasListener encomendasListener;
    private DetalhesEncomendaListener DetalhesEncomendaListener;

    public static synchronized SingletonProdutosGinasio getInstance(Context context) {
        //se tiver, cria um sigleton
        if (instance == null) {
            instance = new SingletonProdutosGinasio(context);
            //iniciar a pilha de pedidos para a API (pedidos assíncronos)
            volleyQueue = Volley.newRequestQueue(context);
        }
        //senão devolve o que tem
        return instance;
    }

    private SingletonProdutosGinasio(Context context) {
        produtos = new ArrayList<>();
        favoritosBD = new FavoritoBdHelper(context);
    }

    public void setLoginListener(LoginListener loginListener) {
        this.loginListener = loginListener;
    }

    public void setUserProfileListener(UserProfileListener userprofileListener) {
        this.UserProfileListener = userprofileListener;
    }

    public void setRegistoListener(RegistoListener registoListener) {
        this.registoListener = registoListener;
    }

    public void setProdutosListener(ProdutosListener produtosListener) {
        this.produtosListener = produtosListener;
    }

    public void setProdutoListener(ProdutoListener produtoListener) {
        this.produtoListener = produtoListener;
    }

    public void setCarrinhoComprasListener(CarrinhoComprasListener carrinhoComprasListener) {
        this.carrinhoComprasListener = carrinhoComprasListener;
    }

    public void setFinalizarCompraListener(FinalizarCompraListener finalizarCompraListener) {
        this.finalizarCompraListener = finalizarCompraListener;
    }

    public void setAvaliacaoListener(AvaliacaoListener avaliacaoListener) {
        this.avaliacaoListener = avaliacaoListener;
    }

    public void setComprasListener(ComprasListener comprasListener) {
        this.comprasListener = comprasListener;
    }

    public void setEncomendasListener(EncomendasListener encomendasListener) {
        this.encomendasListener = encomendasListener;
    }

    public void setDetalhesEncomendaListener(DetalhesEncomendaListener DetalhesencomendaListener) {
        this.DetalhesEncomendaListener = DetalhesencomendaListener;
    }

    public void loginAPI(final Context context, final String IP, String username, String password) {
        final String mUrlAPILogin = "http://" + IP + "/produtosginasio/backend/web/api/login/login";
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            StringRequest reqLogin = new StringRequest(Request.Method.POST, mUrlAPILogin, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Map<String, String> loginData = GinasioJsonParser.parserJsonLogin(response);
                    if (loginListener != null) {
                        loginListener.onValidateLogin(context, loginData.get("auth_key"), loginData.get("username"), loginData.get("email"), Integer.parseInt(loginData.get("profile_id")));
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    String errorMessage = "Ocorreu um erro";
                    if (error.networkResponse != null && error.networkResponse.data != null) {
                        try {
                            String responseBody = new String(error.networkResponse.data, "utf-8");
                            JSONObject jsonObject = new JSONObject(responseBody);
                            errorMessage = jsonObject.getString("message");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show();
                }
            }) {
                @Override
                public String getBodyContentType() {
                    return "application/x-www-form-urlencoded; charset=UTF-8";
                }

                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("username", username);
                    params.put("password", password);
                    return params;
                }


            };
            volleyQueue.add(reqLogin);
        }
    }

    public void getDadosuserprofileAPI(final Context context, String IP, String AUTH_KEY) {
        final String mUrlAPIDadosuserprofile = "http://" + IP + "/produtosginasio/backend/web/api/user/dadosuserprofile?auth_key=" + AUTH_KEY;
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            StringRequest reqDadosuserprofile = new StringRequest(Request.Method.GET, mUrlAPIDadosuserprofile, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Map<String, String> dadosUserProfile = GinasioJsonParser.parserJsonDadosuserprofile(response);

                    if (UserProfileListener != null) {
                        UserProfileListener.onRefreshDetalhes(dadosUserProfile);
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    String errorMessage = "Ocorreu um erro";
                    if (error.networkResponse != null && error.networkResponse.data != null) {
                        try {
                            String responseBody = new String(error.networkResponse.data, "utf-8");
                            JSONObject jsonObject = new JSONObject(responseBody);
                            errorMessage = jsonObject.getString("message");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show();
                }
            });

            volleyQueue.add(reqDadosuserprofile);
        }
    }

    public void ataulizarUserAPI(final Context context, final String IP, final String AUTH_KEY, final User user) {
        final String mUrlAPIAtualizarUser = "http://" + IP + "/produtosginasio/backend/web/api/user/atualizaruser?auth_key=" + AUTH_KEY;
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            StringRequest reqAtualizarUser = new StringRequest(Request.Method.PUT, mUrlAPIAtualizarUser, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Map<String, String> AtualizarUserData = GinasioJsonParser.parserJsonAtualizarUser(response);

                    if (UserProfileListener != null) {
                        UserProfileListener.onValidateAtualizar(context);
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    String errorMessage = "Ocorreu um erro";
                    if (error.networkResponse != null && error.networkResponse.data != null) {
                        try {
                            String responseBody = new String(error.networkResponse.data, "utf-8");
                            JSONObject jsonObject = new JSONObject(responseBody);
                            errorMessage = jsonObject.getString("message");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show();
                }
            }) {
                @Override
                public String getBodyContentType() {
                    return "application/x-www-form-urlencoded; charset=UTF-8";
                }

                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("username", user.getUsername());
                    params.put("email", user.getEmail());
                    params.put("password", user.getPassword());
                    params.put("nif", user.getNif() + "");
                    params.put("morada", user.getMorada());
                    params.put("telefone", user.getTelefone() + "");
                    return params;
                }


            };
            volleyQueue.add(reqAtualizarUser);
        }
    }

    public void registoUserAPI(final Context context, final String IP, final User user) {
        final String mUrlAPIRegistoUser = "http://" + IP + "/produtosginasio/backend/web/api/login/criaruser";
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            StringRequest reqRegistoUser = new StringRequest(Request.Method.POST, mUrlAPIRegistoUser, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    User user = GinasioJsonParser.parserJsonRegistoUser(response);

                    if (registoListener != null) {
                        registoListener.onValidateRegister(context);
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    String errorMessage = "Ocorreu um erro";
                    if (error.networkResponse != null && error.networkResponse.data != null) {
                        try {
                            String responseBody = new String(error.networkResponse.data, "utf-8");
                            JSONObject jsonObject = new JSONObject(responseBody);
                            errorMessage = jsonObject.getString("message");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show();
                }
            }) {
                @Override
                public String getBodyContentType() {
                    return "application/x-www-form-urlencoded; charset=UTF-8";
                }

                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("username", user.getUsername());
                    params.put("email", user.getEmail());
                    params.put("password", user.getPassword());
                    params.put("nif", user.getNif() + "");
                    params.put("morada", user.getMorada());
                    params.put("telefone", user.getTelefone() + "");
                    return params;
                }


            };
            volleyQueue.add(reqRegistoUser);
        }
    }

    public Produto getProduto(int id) {
        for (Produto produto : produtos) {
            if (produto.getId() == id) {
                return produto;
            }
        }
        return null;
    }

    public void getAllProdutosAPI(final Context context, String IP, String AUTH_KEY) {
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            final String mUrlAPIProdutos = "http://" + IP + "/produtosginasio/backend/web/api/produto/produtos?auth_key=" + AUTH_KEY;
            JsonArrayRequest reqSelect = new JsonArrayRequest(Request.Method.GET, mUrlAPIProdutos, null, new Response.Listener<JSONArray>() {
                @Override
                public void onResponse(JSONArray response) {
                    produtos = GinasioJsonParser.parserJsonProdutos(response);

                    //TODO: atualizar a vista
                    if (produtosListener != null) {
                        produtosListener.onRefreshListaProdutos(produtos);
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    String errorMessage = "Ocorreu um erro";
                    if (error.networkResponse != null && error.networkResponse.data != null) {
                        try {
                            String responseBody = new String(error.networkResponse.data, "utf-8");
                            JSONObject jsonObject = new JSONObject(responseBody);
                            errorMessage = jsonObject.getString("message");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show();
                }
            });
            volleyQueue.add(reqSelect);
        }
    }

    public void getLinhasCarrinhoAPI(final Context context, String IP, String AUTH_KEY) {
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            final String mUrlAPILinhasCarrinho = "http://" + IP + "/produtosginasio/backend/web/api/carrinhocompra/carrinho?auth_key=" + AUTH_KEY;
            JsonObjectRequest reqSelect = new JsonObjectRequest(Request.Method.GET, mUrlAPILinhasCarrinho, null, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    linhasCarrinho = GinasioJsonParser.parserJsonLinhasCarrinho(response);

                    //TODO: atualizar a vista
                    if (carrinhoComprasListener != null) {
                        carrinhoComprasListener.onRefreshLinhasCarrinho(linhasCarrinho);
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    String errorMessage = "Ocorreu um erro";
                    if (error.networkResponse != null && error.networkResponse.data != null) {
                        try {
                            String responseBody = new String(error.networkResponse.data, "utf-8");
                            JSONObject jsonObject = new JSONObject(responseBody);
                            errorMessage = jsonObject.getString("message");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show();
                }
            });
            volleyQueue.add(reqSelect);
        }
    }

    public void getDetalhesCarrinhoAPI(final Context context, String IP, String AUTH_KEY) {
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            final String mUrlAPIDetalhesCarrinho = "http://" + IP + "/produtosginasio/backend/web/api/carrinhocompra/detalhescarrinho?auth_key=" + AUTH_KEY;

            StringRequest reqSelect = new StringRequest(Request.Method.GET, mUrlAPIDetalhesCarrinho, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Map<String, String> detalhesCarrinho = GinasioJsonParser.parserJsonDetalhesCarrinho(response);

                    if (carrinhoComprasListener != null) {
                        carrinhoComprasListener.onDetalhesCarrinho(detalhesCarrinho);
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    String errorMessage = "Ocorreu um erro";
                    if (error.networkResponse != null && error.networkResponse.data != null) {
                        try {
                            String responseBody = new String(error.networkResponse.data, "utf-8");
                            JSONObject jsonObject = new JSONObject(responseBody);
                            errorMessage = jsonObject.getString("message");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show();
                }
            });

            // Adicione a requisição à fila
            volleyQueue.add(reqSelect);
        }
    }

    public void adicionarProdutoCarrinhoAPI(final Context context, String AUTH_KEY, String IP, int PRODUTO_ID) {
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            final String mUrlAPIAddProdutoCarrinho = "http://" + IP + "/produtosginasio/backend/web/api/carrinhocompra/adicionarprodutocarrinho?auth_key=" + AUTH_KEY;

            StringRequest reqInsert = new StringRequest(Request.Method.POST, mUrlAPIAddProdutoCarrinho, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    String errorMessage = "Ocorreu um erro";
                    if (error.networkResponse != null && error.networkResponse.data != null) {
                        try {
                            String responseBody = new String(error.networkResponse.data, "utf-8");
                            JSONObject jsonObject = new JSONObject(responseBody);
                            errorMessage = jsonObject.getString("message");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show();
                }
            }) {
                @Nullable
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<>();
                    params.put("produto", String.valueOf(PRODUTO_ID));
                    return params;
                }
            };
            volleyQueue.add(reqInsert);
        }
    }

    public void adicionarQuantidadeProdutoCarrinhoAPI(final Context context, String AUTH_KEY, String IP, int linhaCarrinho) {
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            final String mUrlAPIAddQuantidadeProdutoCarrinho = "http://" + IP + "/produtosginasio/backend/web/api/carrinhocompra/aumentarquantidade?auth_key=" + AUTH_KEY;

            StringRequest reqInsert = new StringRequest(Request.Method.POST, mUrlAPIAddQuantidadeProdutoCarrinho, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    String errorMessage = "Ocorreu um erro";
                    if (error.networkResponse != null && error.networkResponse.data != null) {
                        try {
                            String responseBody = new String(error.networkResponse.data, "utf-8");
                            JSONObject jsonObject = new JSONObject(responseBody);
                            errorMessage = jsonObject.getString("message");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show();
                }
            }) {
                @Nullable
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<>();
                    params.put("linhaCarrinho", String.valueOf(linhaCarrinho));
                    return params;
                }
            };
            volleyQueue.add(reqInsert);
        }
    }

    public void removerQuantidadeProdutoCarrinhoAPI(final Context context, String AUTH_KEY, String IP, int linhaCarrinho) {
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            final String mUrlAPIDeleteQuantidadeProdutoCarrinho = "http://" + IP + "/produtosginasio/backend/web/api/carrinhocompra/diminuirquantidade?auth_key=" + AUTH_KEY;

            StringRequest reqDelete = new StringRequest(Request.Method.POST, mUrlAPIDeleteQuantidadeProdutoCarrinho, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    String errorMessage = "Ocorreu um erro";
                    if (error.networkResponse != null && error.networkResponse.data != null) {
                        try {
                            String responseBody = new String(error.networkResponse.data, "utf-8");
                            JSONObject jsonObject = new JSONObject(responseBody);
                            errorMessage = jsonObject.getString("message");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show();
                }
            }) {
                @Nullable
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<>();
                    params.put("linhaCarrinho", String.valueOf(linhaCarrinho));
                    return params;
                }
            };
            volleyQueue.add(reqDelete);
        }
    }

    public void apagarProdutoCarrinhoAPI(final Context context, String AUTH_KEY, String IP, int linhaCarrinho) {
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            final String mUrlAPIDeleteProdutoCarrinho = "http://" + IP + "/produtosginasio/backend/web/api/carrinhocompra/apagarprodutocarrinho?auth_key=" + AUTH_KEY;

            StringRequest reqDelete = new StringRequest(Request.Method.POST, mUrlAPIDeleteProdutoCarrinho, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    String errorMessage = "Ocorreu um erro";
                    if (error.networkResponse != null && error.networkResponse.data != null) {
                        try {
                            String responseBody = new String(error.networkResponse.data, "utf-8");
                            JSONObject jsonObject = new JSONObject(responseBody);
                            errorMessage = jsonObject.getString("message");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show();
                }
            }) {
                @Nullable
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<>();
                    params.put("linhaCarrinho", String.valueOf(linhaCarrinho));
                    return params;
                }
            };
            volleyQueue.add(reqDelete);
        }
    }

    public void getAllMetodosPagamentosAPI(final Context context, String IP, String AUTH_KEY) {
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            final String mUrlAPIMetodoPagamentos = "http://" + IP + "/produtosginasio/backend/web/api/metodopagamento/metodopagamentos?auth_key=" + AUTH_KEY;
            JsonObjectRequest reqSelect = new JsonObjectRequest(Request.Method.GET, mUrlAPIMetodoPagamentos, null, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    ArrayList<MetodoPagamento> metodoPagamentos = GinasioJsonParser.parserJsonMetodosPagamentos(response);

                    // TODO: atualizar a vista
                    if (finalizarCompraListener != null) {
                        finalizarCompraListener.onRefreshListaMetodosPagamento(metodoPagamentos);
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    String errorMessage = "Ocorreu um erro";
                    if (error.networkResponse != null && error.networkResponse.data != null) {
                        try {
                            String responseBody = new String(error.networkResponse.data, "utf-8");
                            JSONObject jsonObject = new JSONObject(responseBody);
                            errorMessage = jsonObject.getString("message");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show();
                }
            });

            volleyQueue.add(reqSelect);
        }
    }

    public void getAllMetodosEntregasAPI(final Context context, String IP, String AUTH_KEY) {
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            final String mUrlAPIMetodoEntregas = "http://" + IP + "/produtosginasio/backend/web/api/metodoentrega/metodoentregas?auth_key=" + AUTH_KEY;
            JsonObjectRequest reqSelect = new JsonObjectRequest(Request.Method.GET, mUrlAPIMetodoEntregas, null, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    ArrayList<MetodoEntrega> metodoEntregas = GinasioJsonParser.parserJsonMetodosEntregas(response);

                    // TODO: atualizar a vista
                    if (finalizarCompraListener != null) {
                        finalizarCompraListener.onRefreshListaMetodosEntrega(metodoEntregas);
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    String errorMessage = "Ocorreu um erro";
                    if (error.networkResponse != null && error.networkResponse.data != null) {
                        try {
                            String responseBody = new String(error.networkResponse.data, "utf-8");
                            JSONObject jsonObject = new JSONObject(responseBody);
                            errorMessage = jsonObject.getString("message");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show();
                }
            });

            volleyQueue.add(reqSelect);
        }
    }

    public void aplicarCupaoDescontoAPI(final Context context, String AUTH_KEY, String IP, String codigo) {
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            final String mUrlAPIAplicarCupao = "http://" + IP + "/produtosginasio/backend/web/api/carrinhocompra/aplicarcupao?auth_key=" + AUTH_KEY;

            StringRequest reqSelect = new StringRequest(Request.Method.POST, mUrlAPIAplicarCupao, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Map<String, String> codigoCupao = GinasioJsonParser.parserJsonCodigoCupao(response);

                    // TODO: atualizar a vista
                    if (finalizarCompraListener != null) {
                        finalizarCompraListener.onCodigoCupao(codigoCupao);
                    }
                    Toast.makeText(context, "Cupão aplicado com sucesso!", Toast.LENGTH_LONG).show();

                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    String errorMessage = "Ocorreu um erro";
                    if (error.networkResponse != null && error.networkResponse.data != null) {
                        try {
                            String responseBody = new String(error.networkResponse.data, "utf-8");
                            JSONObject jsonObject = new JSONObject(responseBody);
                            errorMessage = jsonObject.getString("message");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show();
                }
            }) {
                @Nullable
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<>();
                    params.put("cupao", codigo);
                    return params;
                }
            };
            volleyQueue.add(reqSelect);
        }
    }

    public void getDadosclienteAPI(final Context context, String IP, String AUTH_KEY) {
        final String mUrlAPIDadoscliente = "http://" + IP + "/produtosginasio/backend/web/api/user/dadosuserprofile?auth_key=" + AUTH_KEY;
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            StringRequest reqDadoscliente = new StringRequest(Request.Method.GET, mUrlAPIDadoscliente, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Map<String, String> dadosCliente = GinasioJsonParser.parserJsonDadoscliente(response);

                    if (finalizarCompraListener != null) {
                        finalizarCompraListener.onDadoscliente(dadosCliente);
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    String errorMessage = "Ocorreu um erro";
                    if (error.networkResponse != null && error.networkResponse.data != null) {
                        try {
                            String responseBody = new String(error.networkResponse.data, "utf-8");
                            JSONObject jsonObject = new JSONObject(responseBody);
                            errorMessage = jsonObject.getString("message");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show();
                }
            });

            volleyQueue.add(reqDadoscliente);
        }
    }

    public void getDetalhesFinalizarCompraAPI(final Context context, String IP, String AUTH_KEY, int metodoEntregaSelecionado, String codigocupao) {
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            final String mUrlAPIDetalhesFinalizarCompra = "http://" + IP + "/produtosginasio/backend/web/api/carrinhocompra/detalhesfinalizarcompra?auth_key=" + AUTH_KEY;

            StringRequest reqSelect = new StringRequest(Request.Method.POST, mUrlAPIDetalhesFinalizarCompra, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Map<String, String> detalhesFinalizarCompra = GinasioJsonParser.parserJsonDetalhesFinalizarCompra(response);

                    if (finalizarCompraListener != null) {
                        finalizarCompraListener.onDetalhesFinalizarCompra(detalhesFinalizarCompra);
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    String errorMessage = "Ocorreu um erro";
                    if (error.networkResponse != null && error.networkResponse.data != null) {
                        try {
                            String responseBody = new String(error.networkResponse.data, "utf-8");
                            JSONObject jsonObject = new JSONObject(responseBody);
                            errorMessage = jsonObject.getString("message");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show();
                }
            }) {
                @Override
                public String getBodyContentType() {
                    return "application/x-www-form-urlencoded; charset=UTF-8";
                }

                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("metodo_entrega", String.valueOf(metodoEntregaSelecionado));
                    params.put("codigo", codigocupao);
                    return params;
                }
            };

            // Adicione a requisição à fila
            volleyQueue.add(reqSelect);
        }
    }

    public void concluirCompraAPI(final Context context, String IP, String AUTH_KEY, int metodoPagamentoSelecionado, int metodoEntregaSelecionado, String codigocupao, String email, int nif, String morada, int telefone) {
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            final String mUrlAPIConcluirCompra = "http://" + IP + "/produtosginasio/backend/web/api/carrinhocompra/concluircompra?auth_key=" + AUTH_KEY;

            StringRequest reqInsert = new StringRequest(Request.Method.POST, mUrlAPIConcluirCompra, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Toast.makeText(context, "Compra realizada com sucesso!", Toast.LENGTH_LONG).show();
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    String errorMessage = "Ocorreu um erro";
                    if (error.networkResponse != null && error.networkResponse.data != null) {
                        try {
                            String responseBody = new String(error.networkResponse.data, "utf-8");
                            JSONObject jsonObject = new JSONObject(responseBody);
                            errorMessage = jsonObject.getString("message");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show();
                }
            }) {
                @Override
                public String getBodyContentType() {
                    return "application/x-www-form-urlencoded; charset=UTF-8";
                }

                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("metodo_pagamento", String.valueOf(metodoPagamentoSelecionado));
                    params.put("metodo_entrega", String.valueOf(metodoEntregaSelecionado));
                    params.put("codigo_cupao", codigocupao);
                    params.put("email", email);
                    params.put("nif", String.valueOf(nif));
                    params.put("morada", morada);
                    params.put("telefone", String.valueOf(telefone));
                    return params;
                }
            };

            // Adicione a requisição à fila
            volleyQueue.add(reqInsert);
        }
    }

    public void registoAvaliacaoAPI(final Context context, final String IP, final String AUTH_KEY, final Avaliacao avaliacao) {
        final String mUrlAPIAvaliacao = "http://" + IP + "/produtosginasio/backend/web/api/avaliacao/criaravaliacao?auth_key=" + AUTH_KEY;
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            StringRequest reqRegistoAvaliacao = new StringRequest(Request.Method.POST, mUrlAPIAvaliacao, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Avaliacao avaliacao = GinasioJsonParser.parserJsonRegistoAvaliacao(response);

                    if (avaliacaoListener != null) {
                        avaliacaoListener.onValidateRegister(context);
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    String errorMessage = "Ocorreu um erro";
                    if (error.networkResponse != null && error.networkResponse.data != null) {
                        try {
                            String responseBody = new String(error.networkResponse.data, "utf-8");
                            JSONObject jsonObject = new JSONObject(responseBody);
                            errorMessage = jsonObject.getString("message");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show();
                }
            }) {
                @Override
                public String getBodyContentType() {
                    return "application/x-www-form-urlencoded; charset=UTF-8";
                }

                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("descricao", avaliacao.getDescricao());
                    params.put("produto", String.valueOf(avaliacao.getProduto_id()));
                    return params;
                }
            };
            volleyQueue.add(reqRegistoAvaliacao);
        }
    }


    public Favorito getFavorito(int id) {
        for (Favorito favorito : favoritos) {
            if (favorito.getId() == id) {
                return favorito;
            }
        }
        return null;
    }

    public void setFavoritoListener(FavoritoListener favoritoListener) {
        this.favoritoListener = favoritoListener;
    }

    public void setFavoritosListener(FavoritosListener favoritosListener) {
        this.favoritosListener = favoritosListener;
    }

    public void adicionarfavoritoBD(Favorito favorito) {
        favoritosBD.adicionarFavoritoBD(favorito);
    }

    public ArrayList<Favorito> getFavoritosBD() {
        favoritos = favoritosBD.getAllFavoritosBD();
        return new ArrayList<>(favoritos);
    }

    public void adicionarFavoritosBD(ArrayList<Favorito> favoritos) {
        favoritosBD.removerAllFavoritoBD();
        for (Favorito f : favoritos)
            adicionarfavoritoBD(f);
    }

    public void removerFavoritosBD(int id) {
        Favorito f = getFavorito(id);
        if (f != null) {
            favoritosBD.removerFavoritoBD(id);
        }
    }

    public void adicionarFavoritoAPI(final Favorito favorito, String IP, final Context context, String AUTH_KEY) {
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            final String mUrlAPIFavorito = "http://" + IP + "/produtosginasio/backend/web/api/favorito/atribuirprodutofavorito?auth_key=" + AUTH_KEY;

            StringRequest reqInsert = new StringRequest(Request.Method.POST, mUrlAPIFavorito, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Favorito favorito = GinasioJsonParser.parserJsonFavorito(response);
                    adicionarfavoritoBD(favorito);
                    if (favoritoListener != null) {
                        favoritoListener.onRefreshDetalhes(ListaFavoritosFragment.ADD);
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    String errorMessage = "Ocorreu um erro";
                    if (error.networkResponse != null && error.networkResponse.data != null) {
                        try {
                            String responseBody = new String(error.networkResponse.data, "utf-8");
                            JSONObject jsonObject = new JSONObject(responseBody);
                            errorMessage = jsonObject.getString("message");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show();
                }
            }) {
                @Nullable
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<>();
                    params.put("produto", Integer.toString(favorito.getProduto_id()));
                    return params;
                }
            };
            volleyQueue.add(reqInsert);
        }
    }


    //TODO PARTE DO REMOVER FALTA REALIZAR
    public void removerFavoritoAPI(final Context context, String AUTH_KEY, String IP, int favoritoId) {
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            final String urlAPIDeleteFavorito = "http://" + IP + "/produtosginasio/backend/web/api/favorito/apagarprodutofavorito?auth_key=" + AUTH_KEY;

            // Criação da requisição DELETE
            StringRequest reqDelete = new StringRequest(Request.Method.POST, urlAPIDeleteFavorito,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            // Exibe a mensagem de sucesso
                            Toast.makeText(context, "Favorito removido com sucesso!", Toast.LENGTH_SHORT).show();
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            String errorMessage = "Ocorreu um erro ao remover o favorito";
                            if (error.networkResponse != null && error.networkResponse.data != null) {
                                try {
                                    String responseBody = new String(error.networkResponse.data, "utf-8");
                                    JSONObject jsonObject = new JSONObject(responseBody);
                                    errorMessage = jsonObject.getString("message");
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                            Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show();
                        }
                    }) {
                @Nullable
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<>();
                    params.put("favorito", String.valueOf(favoritoId));  // Passando o ID do favorito para remover
                    return params;
                }
            };

            // Adiciona a requisição à fila do Volley
            volleyQueue.add(reqDelete);
        }
    }

    public void getAllFavoritosApi(final Context context, String IP, String AUTH_KEY) {
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
            favoritos = getFavoritosBD();

            if (favoritosListener != null) {
                favoritosListener.onRefresListaFavoritos(favoritos);
            }
        } else {
            final String mUrlAPIFavorito = "http://" + IP + "/produtosginasio/backend/web/api/favorito/favoritos?auth_key=" + AUTH_KEY;
            ;
            JsonArrayRequest reqSelect = new JsonArrayRequest(Request.Method.GET, mUrlAPIFavorito, null, new Response.Listener<JSONArray>() {
                @Override
                public void onResponse(JSONArray response) {
                    favoritos = GinasioJsonParser.parserJsonFavoritos(response);
                    // só para funcionalidades offline
                    adicionarFavoritosBD(favoritos);

                    if (favoritosListener != null) {
                        favoritosListener.onRefresListaFavoritos(favoritos);
                    } else {
                        Toast.makeText(context, "A resposta da API está vazia ou nula", Toast.LENGTH_LONG).show();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    String errorMessage = "Ocorreu um erro";
                    if (error.networkResponse != null && error.networkResponse.data != null) {
                        try {
                            String responseBody = new String(error.networkResponse.data, "utf-8");
                            JSONObject jsonObject = new JSONObject(responseBody);
                            errorMessage = jsonObject.getString("message");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show();
                }
            });
            volleyQueue.add(reqSelect);
        }
    }


    public void getAllComprasAPI(final Context context, String IP, String AUTH_KEY) {
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            final String mUrlAPICompras = "http://" + IP + "/produtosginasio/backend/web/api/fatura/compras?auth_key=" + AUTH_KEY;
            JsonArrayRequest reqSelect = new JsonArrayRequest(Request.Method.GET, mUrlAPICompras, null, new Response.Listener<JSONArray>() {
                @Override
                public void onResponse(JSONArray response) {
                    compras = GinasioJsonParser.parserJsonCompras(response);

                    //TODO: atualizar a vista
                    if (comprasListener != null) {
                        comprasListener.onRefreshCompras(compras);
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    String errorMessage = "Ocorreu um erro";
                    if (error.networkResponse != null && error.networkResponse.data != null) {
                        try {
                            String responseBody = new String(error.networkResponse.data, "utf-8");
                            JSONObject jsonObject = new JSONObject(responseBody);
                            errorMessage = jsonObject.getString("message");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show();
                }
            }) {
                /*@Override
                public Map<String, String> getHeaders() {
                    Map<String, String> params = new HashMap<>();
                    params.put("auth_key", AUTH_KEY);
                    return params;
                }*/
                /*@Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> headers = new HashMap<>();
                    // Adiciona o cabeçalho Authorization com a chave da API
                    headers.put("Authorization", "APIKey " + AUTH_KEY);
                    return headers;
                }*/
            };
            volleyQueue.add(reqSelect);
        }
    }

    public void downloadFaturaAPI(final Context context, String IP, String AUTH_KEY, int faturaID) {
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            final String mUrlAPIFatura = "http://" + IP + "/produtosginasio/backend/web/api/fatura/download?auth_key=" + AUTH_KEY;
            InputStreamVolleyRequest request = new InputStreamVolleyRequest(Request.Method.POST, mUrlAPIFatura,
                    new Response.Listener<byte[]>() {
                        @Override
                        public void onResponse(byte[] response) {
                            try {
                                if (response != null) {
                                    savePdf(context, response, faturaID);
                                }
                            } catch (Exception e) {
                                Toast.makeText(context, "Erro ao processar o PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
                            }
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    String errorMessage = "Ocorreu um erro";
                    if (error.networkResponse != null && error.networkResponse.data != null) {
                        try {
                            String responseBody = new String(error.networkResponse.data, "utf-8");
                            JSONObject jsonObject = new JSONObject(responseBody);
                            errorMessage = jsonObject.getString("message");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show();
                }
            }, new HashMap<String, String>() {
                {
                    put("fatura", String.valueOf(faturaID));
                }
            }
            );
            volleyQueue.add(request);
        }
    }

    public void savePdf(Context context, byte[] pdfData, int faturaID) {
        try {
            File path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            File pdfFile = new File(path, "fatura_" + faturaID + ".pdf");
            FileOutputStream fos = new FileOutputStream(pdfFile);
            fos.write(pdfData);
            fos.close();
            Toast.makeText(context, "Fatura descarregada com sucesso!", Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            Toast.makeText(context, "Erro ao salvar a fatura: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public class InputStreamVolleyRequest extends Request<byte[]> {
        private final Response.Listener<byte[]> mListener;
        private final Map<String, String> mParams;

        public InputStreamVolleyRequest(int method, String url, Response.Listener<byte[]> listener,
                                        Response.ErrorListener errorListener, Map<String, String> params) {
            super(method, url, errorListener);
            this.mListener = listener;
            this.mParams = params;
        }

        @Override
        protected Map<String, String> getParams() throws AuthFailureError {
            return mParams;
        }

        @Override
        protected Response<byte[]> parseNetworkResponse(NetworkResponse response) {
            return Response.success(response.data, HttpHeaderParser.parseCacheHeaders(response));
        }

        @Override
        protected void deliverResponse(byte[] response) {
            mListener.onResponse(response);
        }
    }

    public void getEncomendasAPI(final Context context, String IP, String AUTH_KEY) {
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            final String mUrlAPIEncomendas = "http://" + IP + "/produtosginasio/backend/web/api/encomenda/encomendas?auth_key=" + AUTH_KEY;
            JsonArrayRequest reqSelect = new JsonArrayRequest(Request.Method.GET, mUrlAPIEncomendas, null, new Response.Listener<JSONArray>() {
                @Override
                public void onResponse(JSONArray response) {
                    encomendas = GinasioJsonParser.parserJsonEncomendas(response);

                    //TODO: atualizar a vista
                    if (encomendasListener != null) {
                        encomendasListener.onRefreshEncomendas(encomendas);
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    String errorMessage = "Ocorreu um erro";
                    if (error.networkResponse != null && error.networkResponse.data != null) {
                        try {
                            String responseBody = new String(error.networkResponse.data, "utf-8");
                            JSONObject jsonObject = new JSONObject(responseBody);
                            errorMessage = jsonObject.getString("message");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show();
                }
            });
            volleyQueue.add(reqSelect);
        }
    }

    public void getDetalhesEncomendaAPI(final Context context, String IP, String AUTH_KEY, int encomendaID) {
        final String mUrlAPIDetalhesEncomendas = "http://" + IP + "/produtosginasio/backend/web/api/encomenda/detalhesencomenda?auth_key=" + AUTH_KEY;
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            StringRequest reqDetalhesEncomenda = new StringRequest(Request.Method.POST, mUrlAPIDetalhesEncomendas, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    DetalhesEncomenda detalhesEncomenda = GinasioJsonParser.parserJsonDetalhesEncomenda(response);

                    if (DetalhesEncomendaListener != null) {
                        DetalhesEncomendaListener.onRefreshDetalhes(detalhesEncomenda);
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    String errorMessage = "Ocorreu um erro";
                    if (error.networkResponse != null && error.networkResponse.data != null) {
                        try {
                            String responseBody = new String(error.networkResponse.data, "utf-8");
                            JSONObject jsonObject = new JSONObject(responseBody);
                            errorMessage = jsonObject.getString("message");
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show();
                }
            }) {
                @Override
                public String getBodyContentType() {
                    return "application/x-www-form-urlencoded; charset=UTF-8";
                }

                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("encomenda", String.valueOf(encomendaID));
                    return params;
                }


            };
            volleyQueue.add(reqDetalhesEncomenda);
        }
    }
}
