package pt.ipleiria.estg.projeto.produtosginasio.modelo;

import android.content.Context;
import android.os.Environment;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NetworkResponse;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.HttpHeaderParser;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import pt.ipleiria.estg.projeto.produtosginasio.ListaFavoritosFragment;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.AvaliacaoListener;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.ComprasListener;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.DetalhesEncomendaListener;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.EncomendasListener;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.FavoritoListener;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.FavoritosListener;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.LoginListener;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.ProdutoListener;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.ProdutosListener;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.RegistoListener;
import pt.ipleiria.estg.projeto.produtosginasio.listeners.UserProfileListener;
import pt.ipleiria.estg.projeto.produtosginasio.utils.GinasioJsonParser;

public class SingletonProdutosGinasio {
    private static SingletonProdutosGinasio instance = null;
    private static RequestQueue volleyQueue = null;
    private ArrayList<Produto> produtos;
    private ArrayList<Compra> compras;
    private ArrayList<Encomenda> encomendas;
    private LoginListener loginListener;
    private UserProfileListener UserProfileListener;
    private RegistoListener registoListener;
    private AvaliacaoListener avaliacaoListener;
    private ArrayList<Favorito> favoritos;
    private FavoritoBdHelper favoritosBD;
    private FavoritosListener favoritosListener;
    private FavoritoListener favoritoListener;
    private ProdutosListener produtosListener;
    private ProdutoListener produtoListener;
    private ComprasListener comprasListener;
    private EncomendasListener encomendasListener;
    private DetalhesEncomendaListener DetalhesEncomendaListener;

    public static synchronized SingletonProdutosGinasio getInstance(Context context) {
        //se tiver, cria um sigleton
        if (instance == null) {
            instance = new SingletonProdutosGinasio(context);
            //iniciar a pilha de pedidos para a API (pedidos assíncronos)
            volleyQueue = Volley.newRequestQueue(context);
        }
        //senão devolve o que tem
        return instance;
    }

    private SingletonProdutosGinasio(Context context) {
        produtos = new ArrayList<>();
        favoritosBD = new FavoritoBdHelper(context);
    }

    public void setLoginListener(LoginListener loginListener) {
        this.loginListener = loginListener;
    }

    public void setUserProfileListener(UserProfileListener userprofileListener) {
        this.UserProfileListener = userprofileListener;
    }

    public void setRegistoListener(RegistoListener registoListener) {
        this.registoListener = registoListener;
    }

    public void setProdutosListener(ProdutosListener produtosListener) {
        this.produtosListener = produtosListener;
    }

    public void setProdutoListener(ProdutoListener produtoListener) {
        this.produtoListener = produtoListener;
    }

    public void setAvaliacaoListener(AvaliacaoListener avaliacaoListener) {
        this.avaliacaoListener = avaliacaoListener;
    }

    public void setComprasListener(ComprasListener comprasListener) {
        this.comprasListener = comprasListener;
    }

    public void setEncomendasListener(EncomendasListener encomendasListener) {
        this.encomendasListener = encomendasListener;
    }

    public void setDetalhesEncomendaListener(DetalhesEncomendaListener DetalhesencomendaListener) {
        this.DetalhesEncomendaListener = DetalhesencomendaListener;
    }

    public void loginAPI(final Context context, final String IP, String username, String password) {
        final String mUrlAPILogin = "http://" + IP + "/produtosginasio/backend/web/api/login/login";
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            StringRequest reqLogin = new StringRequest(Request.Method.POST, mUrlAPILogin, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Map<String, String> loginData = GinasioJsonParser.parserJsonLogin(response);
                    if (loginListener != null) {
                        loginListener.onValidateLogin(context, loginData.get("auth_key"), loginData.get("username"), loginData.get("email"), Integer.parseInt(loginData.get("profile_id")));
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, error.getMessage(), Toast.LENGTH_LONG).show();
                }
            }) {
                @Override
                public String getBodyContentType() {
                    return "application/x-www-form-urlencoded; charset=UTF-8";
                }

                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("username", username);
                    params.put("password", password);
                    return params;
                }


            };
            volleyQueue.add(reqLogin);
        }
    }

    public void getDadosuserprofileAPI(final Context context, String IP, String AUTH_KEY) {
        final String mUrlAPIDadosuserprofile = "http://" + IP + "/produtosginasio/backend/web/api/user/dadosuserprofile?auth_key=" + AUTH_KEY;
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            StringRequest reqDadosuserprofile = new StringRequest(Request.Method.GET, mUrlAPIDadosuserprofile, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Map<String, String> dadosUserProfile = GinasioJsonParser.parserJsonDadosuserprofile(response);

                    if (UserProfileListener != null) {
                        UserProfileListener.onRefreshDetalhes(dadosUserProfile);
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, error.getMessage(), Toast.LENGTH_LONG).show();
                }
            });

            volleyQueue.add(reqDadosuserprofile);
        }
    }

    public void ataulizarUserAPI(final Context context, final String IP, final String AUTH_KEY, final User user) {
        final String mUrlAPIAtualizarUser = "http://" + IP + "/produtosginasio/backend/web/api/user/atualizaruser?auth_key=" + AUTH_KEY;
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            StringRequest reqAtualizarUser = new StringRequest(Request.Method.PUT, mUrlAPIAtualizarUser, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Map<String, String> AtualizarUserData = GinasioJsonParser.parserJsonAtualizarUser(response);

                    if (UserProfileListener != null) {
                        UserProfileListener.onValidateAtualizar(context);
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, error.getMessage(), Toast.LENGTH_LONG).show();
                }
            }) {
                @Override
                public String getBodyContentType() {
                    return "application/x-www-form-urlencoded; charset=UTF-8";
                }

                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("username", user.getUsername());
                    params.put("email", user.getEmail());
                    params.put("password", user.getPassword());
                    params.put("nif", user.getNif() + "");
                    params.put("morada", user.getMorada());
                    params.put("telefone", user.getTelefone() + "");
                    return params;
                }


            };
            volleyQueue.add(reqAtualizarUser);
        }
    }

    public void registoUserAPI(final Context context, final String IP, final User user) {
        final String mUrlAPIRegistoUser = "http://" + IP + "/produtosginasio/backend/web/api/login/criaruser";
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            StringRequest reqRegistoUser = new StringRequest(Request.Method.POST, mUrlAPIRegistoUser, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    User user = GinasioJsonParser.parserJsonRegistoUser(response);

                    if (registoListener != null) {
                        registoListener.onValidateRegister(context);
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, error.getMessage(), Toast.LENGTH_LONG).show();
                }
            }) {
                @Override
                public String getBodyContentType() {
                    return "application/x-www-form-urlencoded; charset=UTF-8";
                }

                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("username", user.getUsername());
                    params.put("email", user.getEmail());
                    params.put("password", user.getPassword());
                    params.put("nif", user.getNif() + "");
                    params.put("morada", user.getMorada());
                    params.put("telefone", user.getTelefone() + "");
                    return params;
                }


            };
            volleyQueue.add(reqRegistoUser);
        }
    }

    public Produto getProduto(int id) {
        for (Produto produto : produtos) {
            if (produto.getId() == id) {
                return produto;
            }
        }
        return null;
    }

    public void getAllProdutosAPI(final Context context, String IP, String AUTH_KEY) {
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            final String mUrlAPIProdutos = "http://" + IP + "/produtosginasio/backend/web/api/produto/produtos?auth_key=" + AUTH_KEY;
            JsonArrayRequest reqSelect = new JsonArrayRequest(Request.Method.GET, mUrlAPIProdutos, null, new Response.Listener<JSONArray>() {
                @Override
                public void onResponse(JSONArray response) {
                    produtos = GinasioJsonParser.parserJsonProdutos(response);

                    //TODO: atualizar a vista
                    if (produtosListener != null) {
                        produtosListener.onRefreshListaProdutos(produtos);
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, error.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
            volleyQueue.add(reqSelect);
        }
    }

    public void registoAvaliacaoAPI(final Context context, final String IP, final String AUTH_KEY, final Avaliacao avaliacao) {
        final String mUrlAPIAvaliacao = "http://" + IP + "/produtosginasio/backend/web/api/avaliacao/criaravaliacao?auth_key=" + AUTH_KEY;
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            StringRequest reqRegistoAvaliacao = new StringRequest(Request.Method.POST, mUrlAPIAvaliacao, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Avaliacao avaliacao = GinasioJsonParser.parserJsonRegistoAvaliacao(response);

                    if (avaliacaoListener != null) {
                        avaliacaoListener.onValidateRegister(context);
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, error.getMessage(), Toast.LENGTH_LONG).show();
                }
            }) {
                @Override
                public String getBodyContentType() {
                    return "application/x-www-form-urlencoded; charset=UTF-8";
                }

                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("descricao", avaliacao.getDescricao());
                    params.put("produto", String.valueOf(avaliacao.getProduto_id()));
                    return params;
                }
            };
            volleyQueue.add(reqRegistoAvaliacao);
        }
    }


    public Favorito getFavorito(int id) {
        for (Favorito favorito : favoritos) {
            if (favorito.getId() == id) {
                return favorito;
            }
        }
        return null;
    }

    public void setFavoritoListener(FavoritoListener favoritoListener) {
        this.favoritoListener = favoritoListener;
    }

    public void setFavoritosListener(FavoritosListener favoritosListener) {
        this.favoritosListener = favoritosListener;
    }

    public void adicionarfavoritoBD(Favorito favorito) {
        favoritosBD.adicionarFavoritoBD(favorito);
    }

    public ArrayList<Favorito> getFavoritosBD() {
        favoritos = favoritosBD.getAllFavoritosBD();
        return new ArrayList<>(favoritos);
    }

    public void adicionarFavoritosBD(ArrayList<Favorito> favoritos) {
        favoritosBD.removerAllFavoritoBD();
        for (Favorito f : favoritos)
            adicionarfavoritoBD(f);
    }

    public void removerFavoritosBD(int id) {
        Favorito f = getFavorito(id);
        if (f != null) {
            favoritosBD.removerFavoritoBD(id);
        }
    }

    public void adicionarFavoritoAPI(final Favorito favorito, String IP, final Context context, String AUTH_KEY) {
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            final String mUrlAPIFavorito = "http://" + IP + "/produtosginasio/backend/web/api/favorito/atribuirprodutofavorito?auth_key=" + AUTH_KEY;

            StringRequest reqInsert = new StringRequest(Request.Method.POST, mUrlAPIFavorito, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Favorito favorito = GinasioJsonParser.parserJsonFavorito(response);
                    adicionarfavoritoBD(favorito);
                    if (favoritoListener != null) {
                        favoritoListener.onRefreshDetalhes(ListaFavoritosFragment.ADD);
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, error.getMessage(), Toast.LENGTH_LONG).show();
                }
            }) {
                @Nullable
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<>();
                    params.put("produto", Integer.toString(favorito.getProduto_id()));
                    return params;
                }
            };
            volleyQueue.add(reqInsert);
        }
    }


    //TODO PARTE DO REMOVER FALTA REALIZAR
    /*public void removerFavoritoAPI(final Favorito favorito,String IP ,final Context context,String AUTH_KEY){
    if(!GinasioJsonParser.isConnectionInternet(context)){
        Toast.makeText(context,"Sem ligação à internet",Toast.LENGTH_LONG).show();
    }else{
        final String mUrlAPIFavorito = "http://" + IP + "/produtosginasio/backend/web/api/favorito/apagarprodutofavorito?auth_key=" + AUTH_KEY;

        StringRequest reqDelete = new StringRequest(Request.Method.DELETE, mUrlAPIFavorito + "/" + favorito.getId(), new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                removerFavoritosBD(favorito.getId());
                if (favoritosListener != null) {
                    favoritoListener.onRefreshDetalhes(ListaFavoritosFragment.DELETE);
                }
                //atualiza a vista
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(context, error.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
        volleyQueue.add(reqDelete);
    }
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            final String mUrlAPIFavorito = "http://" + IP + "/produtosginasio/backend/web/api/favorito/apagarprodutofavorito?auth_key=" + AUTH_KEY;

            StringRequest reqDelete = new StringRequest(Request.Method.DELETE, mUrlAPIFavorito, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    // Remove o favorito do banco de dados local
                    removerFavoritosBD(favorito.getId());

                    // Notifica a atualização da lista de favoritos no fragmento
                    if (favoritoListener != null) {
                        favoritoListener.onRefreshDetalhes(ListaFavoritosFragment.DELETE);
                    }

                    // Atualize a interface do usuário após a remoção
                    Toast.makeText(context, "Favorito removido com sucesso!", Toast.LENGTH_SHORT).show();
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, error.getMessage(), Toast.LENGTH_LONG).show();
                }
            })
            {
                @Override
                public String getBodyContentType() {
                    return "application/x-www-form-urlencoded; charset=UTF-8";
                }
                @Override
                protected Map<String, String> getParams(){
                    Map<String,String> params=new HashMap<>();
                    params.put("favorito", Integer.toString(favorito.getId()));
                    return params;
                }
            };



            // Adiciona a requisição à fila Volley
            volleyQueue.add(reqDelete);
        }
    }*/

    public void getAllFavoritosApi(final Context context, String IP, String AUTH_KEY) {
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
            favoritos = getFavoritosBD();

            if (favoritosListener != null) {
                favoritosListener.onRefresListaFavoritos(favoritos);
            }
        } else {
            final String mUrlAPIFavorito = "http://" + IP + "/produtosginasio/backend/web/api/favorito/favoritos?auth_key=" + AUTH_KEY;
            ;
            JsonArrayRequest reqSelect = new JsonArrayRequest(Request.Method.GET, mUrlAPIFavorito, null, new Response.Listener<JSONArray>() {
                @Override
                public void onResponse(JSONArray response) {
                    favoritos = GinasioJsonParser.parserJsonFavoritos(response);
                    // só para funcionalidades offline
                    adicionarFavoritosBD(favoritos);

                    if (favoritosListener != null) {
                        favoritosListener.onRefresListaFavoritos(favoritos);
                    } else {
                        Toast.makeText(context, "A resposta da API está vazia ou nula", Toast.LENGTH_LONG).show();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    // Verifica o tipo de erro
                    String errorMessage = "Erro desconhecido";

                    if (error instanceof NetworkError) {
                        errorMessage = "Erro de rede, sem conexão com a internet";
                    } else if (error instanceof ServerError) {
                        errorMessage = "Erro do servidor. Tente mais tarde.";
                    } else if (error instanceof AuthFailureError) {
                        errorMessage = "Erro de autenticação";
                    } else if (error instanceof ParseError) {
                        errorMessage = "Erro ao parsear a resposta JSON";
                    } else if (error instanceof TimeoutError) {
                        errorMessage = "Tempo de resposta excedido";
                    }

                    // Exibe o erro no Logcat para depuração
                    Log.e("API Error", errorMessage + " - " + error.toString());

                    // Exibe uma mensagem de erro para o usuário
                    Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show();
                }
            });
            volleyQueue.add(reqSelect);
        }
    }


    public void getAllComprasAPI(final Context context, String IP, String AUTH_KEY) {
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            final String mUrlAPICompras = "http://" + IP + "/produtosginasio/backend/web/api/fatura/compras?auth_key=" + AUTH_KEY;
            JsonArrayRequest reqSelect = new JsonArrayRequest(Request.Method.GET, mUrlAPICompras, null, new Response.Listener<JSONArray>() {
                @Override
                public void onResponse(JSONArray response) {
                    compras = GinasioJsonParser.parserJsonCompras(response);

                    //TODO: atualizar a vista
                    if (comprasListener != null) {
                        comprasListener.onRefreshCompras(compras);
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, error.getMessage(), Toast.LENGTH_LONG).show();
                }
            }) {
                /*@Override
                public Map<String, String> getHeaders() {
                    Map<String, String> params = new HashMap<>();
                    params.put("auth_key", AUTH_KEY);
                    return params;
                }*/
                /*@Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    Map<String, String> headers = new HashMap<>();
                    // Adiciona o cabeçalho Authorization com a chave da API
                    headers.put("Authorization", "APIKey " + AUTH_KEY);
                    return headers;
                }*/
            };
            volleyQueue.add(reqSelect);
        }
    }

    public void downloadFaturaAPI(final Context context, String IP, String AUTH_KEY, int faturaID) {
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            final String mUrlAPIFatura = "http://" + IP + "/produtosginasio/backend/web/api/fatura/download?auth_key=" + AUTH_KEY;
            InputStreamVolleyRequest request = new InputStreamVolleyRequest(Request.Method.POST, mUrlAPIFatura,
                    new Response.Listener<byte[]>() {
                        @Override
                        public void onResponse(byte[] response) {
                            try {
                                if (response != null) {
                                    savePdf(context, response, faturaID);
                                }
                            } catch (Exception e) {
                                Toast.makeText(context, "Erro ao processar o PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
                            }
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, "Erro: " + error.getMessage(), Toast.LENGTH_LONG).show();
                }
            }, new HashMap<String, String>() {
                {
                    put("fatura", String.valueOf(faturaID));
                }
            }
            );
            volleyQueue.add(request);
        }
    }

    public void savePdf(Context context, byte[] pdfData, int faturaID) {
        try {
            File path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            File pdfFile = new File(path, "fatura_" + faturaID + ".pdf");
            FileOutputStream fos = new FileOutputStream(pdfFile);
            fos.write(pdfData);
            fos.close();
            Toast.makeText(context, "Fatura descarregada com sucesso!", Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            Toast.makeText(context, "Erro ao salvar a fatura: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public class InputStreamVolleyRequest extends Request<byte[]> {
        private final Response.Listener<byte[]> mListener;
        private final Map<String, String> mParams;

        public InputStreamVolleyRequest(int method, String url, Response.Listener<byte[]> listener,
                                        Response.ErrorListener errorListener, Map<String, String> params) {
            super(method, url, errorListener);
            this.mListener = listener;
            this.mParams = params;
        }

        @Override
        protected Map<String, String> getParams() throws AuthFailureError {
            return mParams;
        }

        @Override
        protected Response<byte[]> parseNetworkResponse(NetworkResponse response) {
            return Response.success(response.data, HttpHeaderParser.parseCacheHeaders(response));
        }

        @Override
        protected void deliverResponse(byte[] response) {
            mListener.onResponse(response);
        }
    }

    public void getEncomendasAPI(final Context context, String IP, String AUTH_KEY) {
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            final String mUrlAPIEncomendas = "http://" + IP + "/produtosginasio/backend/web/api/encomenda/encomendas?auth_key=" + AUTH_KEY;
            JsonArrayRequest reqSelect = new JsonArrayRequest(Request.Method.GET, mUrlAPIEncomendas, null, new Response.Listener<JSONArray>() {
                @Override
                public void onResponse(JSONArray response) {
                    encomendas = GinasioJsonParser.parserJsonEncomendas(response);

                    //TODO: atualizar a vista
                    if (encomendasListener != null) {
                        encomendasListener.onRefreshEncomendas(encomendas);
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, error.getMessage(), Toast.LENGTH_LONG).show();
                }
            });
            volleyQueue.add(reqSelect);
        }
    }

    public void getDetalhesEncomendaAPI(final Context context, String IP, String AUTH_KEY, int encomendaID) {
        final String mUrlAPIDetalhesEncomendas = "http://" + IP + "/produtosginasio/backend/web/api/encomenda/detalhesencomenda?auth_key=" + AUTH_KEY;
        if (!GinasioJsonParser.isConnectionInternet(context)) {
            Toast.makeText(context, "Sem ligação à internet", Toast.LENGTH_LONG).show();
        } else {
            StringRequest reqDetalhesEncomenda = new StringRequest(Request.Method.POST, mUrlAPIDetalhesEncomendas, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    DetalhesEncomenda detalhesEncomenda = GinasioJsonParser.parserJsonDetalhesEncomenda(response);

                    if (DetalhesEncomendaListener != null) {
                        DetalhesEncomendaListener.onRefreshDetalhes(detalhesEncomenda);
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(context, error.getMessage(), Toast.LENGTH_LONG).show();
                }
            }) {
                @Override
                public String getBodyContentType() {
                    return "application/x-www-form-urlencoded; charset=UTF-8";
                }

                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("encomenda", String.valueOf(encomendaID));
                    return params;
                }


            };
            volleyQueue.add(reqDetalhesEncomenda);
        }
    }
}
