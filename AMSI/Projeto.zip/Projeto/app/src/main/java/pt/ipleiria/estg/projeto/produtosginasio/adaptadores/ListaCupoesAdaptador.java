package pt.ipleiria.estg.projeto.produtosginasio.adaptadores;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import java.util.ArrayList;

import pt.ipleiria.estg.projeto.produtosginasio.R;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Cupao;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Produto;

public class ListaCupoesAdaptador extends BaseAdapter {
    private Context context;
    private LayoutInflater inflater;
    private ArrayList<Cupao> cupoes;

    public ListaCupoesAdaptador(Context context, ArrayList<Cupao> cupoes) {
        this.context = context;
        this.cupoes = cupoes;
    }

    @Override
    public int getCount() {
        return cupoes.size();
    }

    @Override
    public Object getItem(int i) {
        return cupoes.get(i);
    }

    @Override
    public long getItemId(int i) {
        return cupoes.get(i).getId();
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (inflater == null) {
            inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        if (view == null) {
            view = inflater.inflate(R.layout.item_lista_cupao, null);
        }

        ViewHolderLista viewHolder = (ViewHolderLista) view.getTag();
        if (viewHolder == null) {
            viewHolder = new ViewHolderLista(view);
            view.setTag(viewHolder);
        }

        viewHolder.update(cupoes.get(i));

        return view;
    }

    private class ViewHolderLista {
        private ImageView imgCupaoDesconto;
        private TextView tvCodigoCupao, tvDescontoCupao, tvDataFimCupao;

        public ViewHolderLista(View view) {
            tvCodigoCupao = view.findViewById(R.id.tvCodigoCupao);
            tvDescontoCupao = view.findViewById(R.id.tvDescontoCupao);
            tvDataFimCupao = view.findViewById(R.id.tvDataFimCupao);
            imgCupaoDesconto = view.findViewById(R.id.imgCupaoDesconto);
        }

        public void update(Cupao c) {
            tvCodigoCupao.setText(c.getCodigo());
            tvDescontoCupao.setText(c.getDesconto() + "%");
            tvDataFimCupao.setText(c.getDataFim());
            Glide.with(context)
                    .load(R.drawable.ic_image_cupao)
                    .into(imgCupaoDesconto);
        }
    }
}
