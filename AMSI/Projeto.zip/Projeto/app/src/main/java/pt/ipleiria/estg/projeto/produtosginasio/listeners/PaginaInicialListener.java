package pt.ipleiria.estg.projeto.produtosginasio.listeners;

import java.util.ArrayList;

import pt.ipleiria.estg.projeto.produtosginasio.modelo.Cupao;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Produto;

public interface PaginaInicialListener {
    void onRefreshListaCupoesValidos(ArrayList<Cupao> listaCupoes);
    void onRefreshListaProdutos(ArrayList<Produto> listaProdutos);
}
