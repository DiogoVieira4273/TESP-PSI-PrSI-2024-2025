package pt.ipleiria.estg.projeto.produtosginasio.utils;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import pt.ipleiria.estg.projeto.produtosginasio.modelo.Compra;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.DetalhesEncomenda;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Encomenda;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Produto;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.ProdutoDetalhes;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.User;

public class GinasioJsonParser {
    public static Map<String, String> parserJsonLogin(String response) {
        Map<String, String> loginData = new HashMap<>();
        try {
            JSONObject loginJson = new JSONObject(response);
            loginData.put("auth_key", loginJson.getString("auth_key"));
            loginData.put("username", loginJson.getString("username"));
            loginData.put("email", loginJson.getString("email"));
            loginData.put("profile_id", String.valueOf(loginJson.getInt("profile_id")));
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        return loginData;
    }

    public static User parserJsonRegistoUser(String response) {
        User user = null;
        try {
            JSONObject userJson = new JSONObject(response);
            String username = userJson.getString("username");
            String email = userJson.getString("email");
            String password = userJson.getString("password");
            int nif = userJson.getInt("nif");
            String morada = userJson.getString("morada");
            int telefone = userJson.getInt("telefone");

            user = new User(0, username, email, password, nif, morada, telefone);
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        return user;
    }

    public static ArrayList<Produto> parserJsonProdutos(JSONArray response) {

        ArrayList<Produto> produtos = new ArrayList<>();

        for (int i = 0; i < response.length(); i++) {
            JSONObject produtoJson = null;
            try {
                produtoJson = (JSONObject) response.get(i);
                //vai buscar os campo id na API
                int id = produtoJson.getInt("id");
                String nomeProduto = produtoJson.getString("nomeProduto");
                Float preco = (float) produtoJson.getDouble("preco");
                int quantidade = produtoJson.getInt("quantidade");
                String descricaoProduto = produtoJson.getString("descricaoProduto");
                String marca = produtoJson.getString("marca");
                String categoria = produtoJson.getString("categoria");
                float iva = (float) produtoJson.getDouble("iva");
                String genero = produtoJson.getString("genero");
                String imagem = produtoJson.getString("imagem");

                produtos.add(new Produto(id, nomeProduto, preco, quantidade, descricaoProduto, marca, categoria, iva, genero, imagem));
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }
        }
        return produtos;
    }

    public static Produto parserJsonProduto(String response) {
        Produto produto = null;
        try {
            JSONObject produtoJson = new JSONObject(response);
            int id = produtoJson.getInt("id");
            int quantidade = produtoJson.getInt("quantidade");
            float iva = (float) produtoJson.getDouble("iva");
            float preco = (float) produtoJson.getDouble("preco");
            String nomeProduto = produtoJson.getString("nomeProduto");
            String descricaoProduto = produtoJson.getString("descricaoProduto");
            String marca = produtoJson.getString("marca");
            String categoria = produtoJson.getString("categoria");
            String genero = produtoJson.getString("genero");
            String imagem = produtoJson.getString("imagem");
            produto = new Produto(id, nomeProduto, preco, quantidade, descricaoProduto, marca, categoria, iva, genero, imagem);
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        return produto;
    }

    public static ArrayList<Compra> parserJsonCompras(JSONArray response) {

        ArrayList<Compra> compras = new ArrayList<>();

        for (int i = 0; i < response.length(); i++) {
            JSONObject compraJson = null;
            try {
                compraJson = (JSONObject) response.get(i);

                int id = compraJson.getInt("id");
                String dataEmissao = compraJson.getString("dataEmissao");
                String horaEmissao = compraJson.getString("horaEmissao");
                float valorTotal = (float) compraJson.getDouble("valorTotal");
                float ivaTotal = (float) compraJson.getDouble("ivaTotal");
                int nif = compraJson.getInt("nif");
                int metodoPagamento = compraJson.getInt("metodopagamento_id");
                int metodoEntrega = compraJson.getInt("metodoentrega_id");
                int encomendaID = compraJson.getInt("encomenda_id");
                int profileID = compraJson.getInt("profile_id");

                compras.add(new Compra(id, dataEmissao, horaEmissao, valorTotal, ivaTotal, nif, metodoPagamento, metodoEntrega, encomendaID, profileID));
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }
        }
        return compras;
    }

    public static ArrayList<Encomenda> parserJsonEncomendas(JSONArray response) {

        ArrayList<Encomenda> encomendas = new ArrayList<>();

        for (int i = 0; i < response.length(); i++) {
            JSONObject encomendaJson = null;
            try {
                encomendaJson = (JSONObject) response.get(i);

                int encomendaID = encomendaJson.getInt("encomendaID");
                String data = encomendaJson.getString("data");
                String hora = encomendaJson.getString("hora");
                String morada = encomendaJson.getString("morada");
                int telefone = encomendaJson.getInt("telefone");
                String email = encomendaJson.getString("email");
                String estadoEncomenda = encomendaJson.getString("estadoEncomenda");
                int profileID = encomendaJson.getInt("profile_id");

                encomendas.add(new Encomenda(encomendaID, data, hora, morada, telefone, email, estadoEncomenda, profileID));
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }
        }
        return encomendas;
    }

    public static DetalhesEncomenda parserJsonDetalhesEncomenda(String response) {
        DetalhesEncomenda detalhesEncomendas = null;
        try {
            //detalhes da encomenda
            JSONObject responseJson = new JSONObject(response);
            JSONObject encomendaJson = responseJson.getJSONObject("encomenda");
            int encomendaID = encomendaJson.getInt("encomendaID");
            String data = encomendaJson.getString("data");
            String hora = encomendaJson.getString("hora");
            String morada = encomendaJson.getString("morada");
            int telefone = encomendaJson.getInt("telefone");
            String email = encomendaJson.getString("email");
            String estadoEncomenda = encomendaJson.getString("estadoEncomenda");
            int profileID = encomendaJson.getInt("profile_id");

            //produtos associados à encomenda
            JSONArray produtosJson = responseJson.getJSONArray("produtos");
            ArrayList<ProdutoDetalhes> produtos = new ArrayList<>();

            for (int j = 0; j < produtosJson.length(); j++) {
                JSONObject produtoJson = produtosJson.getJSONObject(j);
                String nomeProduto = produtoJson.getString("nomeProduto");
                String precoStr = produtoJson.getString("preco").replace(",", ".");
                float preco = Float.parseFloat(precoStr);
                int quantidade = produtoJson.getInt("quantidade");

                ProdutoDetalhes produto = new ProdutoDetalhes(nomeProduto, preco, quantidade);
                produtos.add(produto);
            }

            detalhesEncomendas = new DetalhesEncomenda(encomendaID, data, hora, morada, telefone, email, estadoEncomenda, profileID, produtos);
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }

        return detalhesEncomendas;
    }

    public static boolean isConnectionInternet(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo ni = cm.getActiveNetworkInfo();
        return ni != null && ni.isConnectedOrConnecting();
    }
}
