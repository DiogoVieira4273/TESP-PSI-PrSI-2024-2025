package pt.ipleiria.estg.projeto.produtosginasio.utils;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import org.json.JSONException;
import org.json.JSONObject;

public class GinasioJsonParser {
    public static String parserJsonLogin(String response) {
        String auth_key = null;
        try {
            JSONObject loginJson = new JSONObject(response);
            auth_key = loginJson.getString("auth_key");
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        return auth_key;
    }

    public static boolean isConnectionInternet(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo ni = cm.getActiveNetworkInfo();
        return ni != null && ni.isConnectedOrConnecting();
    }
}
