package pt.ipleiria.estg.projeto.produtosginasio.utils;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import pt.ipleiria.estg.projeto.produtosginasio.modelo.Avaliacao;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Compra;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Cupao;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.DetalhesEncomenda;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Encomenda;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Favorito;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.LinhasCarrinho;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.MetodoEntrega;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.MetodoPagamento;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Produto;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.ProdutoDetalhes;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.User;

public class GinasioJsonParser {
    public static Map<String, String> parserJsonLogin(String response) {
        Map<String, String> loginData = new HashMap<>();
        try {
            JSONObject loginJson = new JSONObject(response);
            loginData.put("auth_key", loginJson.getString("auth_key"));
            loginData.put("username", loginJson.getString("username"));
            loginData.put("email", loginJson.getString("email"));
            loginData.put("profile_id", String.valueOf(loginJson.getInt("profile_id")));
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        return loginData;
    }

    public static Map<String, String> parserJsonDadosuserprofile(String response) {
        Map<String, String> dadosData = new HashMap<>();
        try {
            JSONObject loginJson = new JSONObject(response);
            dadosData.put("username", loginJson.getString("username"));
            dadosData.put("email", loginJson.getString("email"));
            dadosData.put("nif", String.valueOf(loginJson.getInt("nif")));
            dadosData.put("morada", loginJson.getString("morada"));
            dadosData.put("telefone", String.valueOf(loginJson.getInt("telefone")));
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        return dadosData;
    }

    public static User parserJsonRegistoUser(String response) {
        User user = null;
        try {
            JSONObject userJson = new JSONObject(response);
            String username = userJson.getString("username");
            String email = userJson.getString("email");
            String password = userJson.getString("password");
            int nif = userJson.getInt("nif");
            String morada = userJson.getString("morada");
            int telefone = userJson.getInt("telefone");

            user = new User(0, username, email, password, nif, morada, telefone);
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        return user;
    }

    public static Map<String, String> parserJsonAtualizarUser(String response) {
        Map<String, String> atualizarUserData = new HashMap<>();
        try {
            JSONObject loginJson = new JSONObject(response);
            atualizarUserData.put("auth_key", loginJson.getString("auth_key"));
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        return atualizarUserData;
    }

    public static ArrayList<Cupao> parserJsonCupoesValidos(JSONArray response) {

        ArrayList<Cupao> cupoes = new ArrayList<>();

        for (int i = 0; i < response.length(); i++) {
            JSONObject cupaoJson = null;
            try {
                cupaoJson = (JSONObject) response.get(i);
                //vai buscar os campo id na API
                int id = cupaoJson.getInt("id");
                String codigo = cupaoJson.getString("codigo");
                int desconto = cupaoJson.getInt("desconto");
                String dataFim = cupaoJson.getString("dataFim");

                cupoes.add(new Cupao(id, codigo, desconto, dataFim));
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }
        }
        return cupoes;
    }

    public static ArrayList<Produto> parserJsonUltimosProdutos(JSONArray response) {

        ArrayList<Produto> produtos = new ArrayList<>();

        for (int i = 0; i < response.length(); i++) {
            JSONObject produtoJson = null;
            try {
                produtoJson = (JSONObject) response.get(i);
                //vai buscar os campo id na API
                int id = produtoJson.getInt("id");
                String nomeProduto = produtoJson.getString("nomeProduto");
                Float preco = (float) produtoJson.getDouble("preco");
                int quantidade = produtoJson.getInt("quantidade");
                String descricaoProduto = produtoJson.getString("descricaoProduto");
                String marca = produtoJson.getString("marca");
                String categoria = produtoJson.getString("categoria");
                float iva = (float) produtoJson.getDouble("iva");
                String genero = produtoJson.getString("genero");
                String imagem = produtoJson.getString("imagem");

                produtos.add(new Produto(id, nomeProduto, preco, quantidade, descricaoProduto, marca, categoria, iva, genero, imagem));
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }
        }
        return produtos;
    }

    public static ArrayList<Produto> parserJsonProdutos(JSONArray response) {

        ArrayList<Produto> produtos = new ArrayList<>();

        for (int i = 0; i < response.length(); i++) {
            JSONObject produtoJson = null;
            try {
                produtoJson = (JSONObject) response.get(i);
                //vai buscar os campo id na API
                int id = produtoJson.getInt("id");
                String nomeProduto = produtoJson.getString("nomeProduto");
                Float preco = (float) produtoJson.getDouble("preco");
                int quantidade = produtoJson.getInt("quantidade");
                String descricaoProduto = produtoJson.getString("descricaoProduto");
                String marca = produtoJson.getString("marca");
                String categoria = produtoJson.getString("categoria");
                float iva = (float) produtoJson.getDouble("iva");
                String genero = produtoJson.getString("genero");
                String imagem = produtoJson.getString("imagem");

                produtos.add(new Produto(id, nomeProduto, preco, quantidade, descricaoProduto, marca, categoria, iva, genero, imagem));
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }
        }
        return produtos;
    }

    public static Produto parserJsonProduto(String response) {
        Produto produto = null;
        try {
            JSONObject produtoJson = new JSONObject(response);
            int id = produtoJson.getInt("id");
            int quantidade = produtoJson.getInt("quantidade");
            float iva = (float) produtoJson.getDouble("iva");
            float preco = (float) produtoJson.getDouble("preco");
            String nomeProduto = produtoJson.getString("nomeProduto");
            String descricaoProduto = produtoJson.getString("descricaoProduto");
            String marca = produtoJson.getString("marca");
            String categoria = produtoJson.getString("categoria");
            String genero = produtoJson.getString("genero");
            String imagem = produtoJson.getString("imagem");
            produto = new Produto(id, nomeProduto, preco, quantidade, descricaoProduto, marca, categoria, iva, genero, imagem);
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        return produto;
    }

    public static ArrayList<LinhasCarrinho> parserJsonLinhasCarrinho(JSONObject response) {
        ArrayList<LinhasCarrinho> linhasCarrinho = new ArrayList<>();

        try {
            // Obtém o array "linhasCarrinho" do objeto JSON de resposta
            JSONArray linhasCarrinhoArray = response.getJSONArray("linhasCarrinho");

            for (int i = 0; i < linhasCarrinhoArray.length(); i++) {
                JSONObject linhaJson = linhasCarrinhoArray.getJSONObject(i);

                // Vai buscar os campos na API
                int id = linhaJson.getInt("id");
                int quantidade = linhaJson.getInt("quantidade");
                float precoUnit = (float) linhaJson.getDouble("precoUnit");
                float valorIva = (float) linhaJson.getDouble("valorIva");
                float valorComIva = (float) linhaJson.getDouble("valorComIva");
                float subtotal = (float) linhaJson.getDouble("subtotal");
                int carrinhocomprasId = linhaJson.getInt("carrinhocompras_id");
                String produtoNome = linhaJson.getString("produto_nome");
                String tamanhoNome = linhaJson.getString("tamanho_nome");
                String imagem = linhaJson.getString("imagem");

                linhasCarrinho.add(new LinhasCarrinho(id, quantidade, precoUnit, valorIva, valorComIva, subtotal, carrinhocomprasId, produtoNome, tamanhoNome, imagem));
            }
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        return linhasCarrinho;
    }

    public static Map<String, String> parserJsonDetalhesCarrinho(String response) {
        Map<String, String> dadosData = new HashMap<>();
        try {
            JSONObject detalhescarrinhoJson = new JSONObject(response);
            dadosData.put("quantidade_total", String.valueOf(detalhescarrinhoJson.getInt("quantidade_total")));
            dadosData.put("valorTotal", String.valueOf(detalhescarrinhoJson.getDouble("valorTotal")));
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        return dadosData;
    }

    public static ArrayList<Avaliacao> parserJsonAvaliacoes(JSONArray response) {

        ArrayList<Avaliacao> avaliacoes = new ArrayList<>();

        for (int i = 0; i < response.length(); i++) {
            JSONObject avaliacaoJson = null;
            try {
                avaliacaoJson = (JSONObject) response.get(i);
                //vai buscar os campo id na API
                int id = avaliacaoJson.getInt("id");
                String descricao = avaliacaoJson.getString("descricao");
                int produto_id = avaliacaoJson.getInt("produto_id");
                int profile_id = avaliacaoJson.getInt("profile_id");

                avaliacoes.add(new Avaliacao(id, descricao, produto_id, profile_id));
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }
        }
        return avaliacoes;
    }

    public static Avaliacao parserJsonRegistoAvaliacao(String response) {
        Avaliacao avaliacao = null;
        try {
            JSONObject avaliacaoJson = new JSONObject(response);
            int id = avaliacaoJson.getInt("id");
            String descricao = avaliacaoJson.getString("descricao");
            int produto_id = avaliacaoJson.getInt("produto_id");
            int profile_id = avaliacaoJson.getInt("profile_id");

            avaliacao = new Avaliacao(0, descricao, produto_id, profile_id);
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        return avaliacao;
    }

    public static ArrayList<Favorito> parserJsonFavoritos(JSONArray response) {
        ArrayList<Favorito> favoritos = new ArrayList<>();

        for (int i = 0; i < response.length(); i++) {
            JSONObject favoritoJson = null;
            try {
                favoritoJson = (JSONObject) response.get(i);

                //JSONObject favoritoJson = responseJson.getJSONObject("favorito");

                int id = favoritoJson.getInt("id");
                int produto_id = favoritoJson.getInt("produto_id");
                int profile_id = favoritoJson.getInt("profile_id");
                String nomeProduto = favoritoJson.getString(("nomeProduto"));
                float preco = (float) favoritoJson.getDouble("preco");
                String imagem = favoritoJson.getString("imagem");

                favoritos.add(new Favorito(id, produto_id, profile_id, nomeProduto, preco, imagem));

            } catch (JSONException e) {
                throw new RuntimeException(e);
            }
        }
        return favoritos;
    }

    public static Favorito parserJsonFavorito(String response) {
        Favorito favorito = null;
        try {
            JSONObject favoritoJson = new JSONObject(response);
            int id = favoritoJson.getInt("id");
            int produto_id = favoritoJson.getInt("produto_id");
            int profile_id = favoritoJson.getInt("profile_id");
            String nomeProduto = favoritoJson.getString(("nomeProduto"));
            float preco = (float) favoritoJson.getDouble("preco");
            String imagem = favoritoJson.getString("imagem");

            favorito = new Favorito(id, produto_id, produto_id, nomeProduto, preco, imagem);

        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        return favorito;
    }

    public static ArrayList<Compra> parserJsonCompras(JSONArray response) {

        ArrayList<Compra> compras = new ArrayList<>();

        for (int i = 0; i < response.length(); i++) {
            JSONObject compraJson = null;
            try {
                compraJson = (JSONObject) response.get(i);

                int id = compraJson.getInt("id");
                String dataEmissao = compraJson.getString("dataEmissao");
                String horaEmissao = compraJson.getString("horaEmissao");
                float valorTotal = (float) compraJson.getDouble("valorTotal");
                float ivaTotal = (float) compraJson.getDouble("ivaTotal");
                int nif = compraJson.getInt("nif");
                int metodoPagamento = compraJson.getInt("metodopagamento_id");
                int metodoEntrega = compraJson.getInt("metodoentrega_id");
                int encomendaID = compraJson.getInt("encomenda_id");
                int profileID = compraJson.getInt("profile_id");

                compras.add(new Compra(id, dataEmissao, horaEmissao, valorTotal, ivaTotal, nif, metodoPagamento, metodoEntrega, encomendaID, profileID));
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }
        }
        return compras;
    }

    public static ArrayList<MetodoPagamento> parserJsonMetodosPagamentos(JSONObject response) {
        ArrayList<MetodoPagamento> metodoPagamentos = new ArrayList<>();

        try {
            JSONArray metodosArray = response.getJSONArray("metodopagamentos");

            for (int i = 0; i < metodosArray.length(); i++) {
                JSONObject metodoPagamentoJson = metodosArray.getJSONObject(i);

                int id = metodoPagamentoJson.getInt("id");
                String metodoPagamento = metodoPagamentoJson.getString("metodoPagamento");

                metodoPagamentos.add(new MetodoPagamento(id, metodoPagamento));
            }
        } catch (JSONException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
        return metodoPagamentos;
    }

    public static ArrayList<MetodoEntrega> parserJsonMetodosEntregas(JSONObject response) {
        ArrayList<MetodoEntrega> metodoEntregas = new ArrayList<>();

        try {
            JSONArray metodosArray = response.getJSONArray("metodoentregas");

            for (int i = 0; i < metodosArray.length(); i++) {
                JSONObject metodoEntregaJson = metodosArray.getJSONObject(i);

                int id = metodoEntregaJson.getInt("id");
                String descricao = metodoEntregaJson.getString("descricao");

                metodoEntregas.add(new MetodoEntrega(id, descricao));
            }
        } catch (JSONException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
        return metodoEntregas;
    }

    public static Map<String, String> parserJsonCodigoCupao(String response) {
        Map<String, String> dadosData = new HashMap<>();
        try {
            JSONObject codigocupaoJson = new JSONObject(response);
            dadosData.put("codigoCupao", codigocupaoJson.getString("codigoCupao"));
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        return dadosData;
    }

    public static Map<String, String> parserJsonDadoscliente(String response) {
        Map<String, String> dadosData = new HashMap<>();
        try {
            JSONObject loginJson = new JSONObject(response);
            dadosData.put("email", loginJson.getString("email"));
            dadosData.put("nif", String.valueOf(loginJson.getInt("nif")));
            dadosData.put("morada", loginJson.getString("morada"));
            dadosData.put("telefone", String.valueOf(loginJson.getInt("telefone")));
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        return dadosData;
    }

    public static Map<String, String> parserJsonDetalhesFinalizarCompra(String response) {
        Map<String, String> dadosData = new HashMap<>();
        try {
            JSONObject detalhesfinalizarcompraJson = new JSONObject(response);
            dadosData.put("desconto", detalhesfinalizarcompraJson.getString("desconto"));
            dadosData.put("valorPoupado", detalhesfinalizarcompraJson.getString("valorPoupado"));
            dadosData.put("custoEnvio", detalhesfinalizarcompraJson.getString("custoEnvio"));
            dadosData.put("subtotal", detalhesfinalizarcompraJson.getString("subtotal"));
            dadosData.put("valorTotal", detalhesfinalizarcompraJson.getString("valorTotal"));
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }
        return dadosData;
    }

    public static ArrayList<Encomenda> parserJsonEncomendas(JSONArray response) {

        ArrayList<Encomenda> encomendas = new ArrayList<>();

        for (int i = 0; i < response.length(); i++) {
            JSONObject encomendaJson = null;
            try {
                encomendaJson = (JSONObject) response.get(i);

                int encomendaID = encomendaJson.getInt("encomendaID");
                String data = encomendaJson.getString("data");
                String hora = encomendaJson.getString("hora");
                String morada = encomendaJson.getString("morada");
                int telefone = encomendaJson.getInt("telefone");
                String email = encomendaJson.getString("email");
                String estadoEncomenda = encomendaJson.getString("estadoEncomenda");
                int profileID = encomendaJson.getInt("profile_id");

                encomendas.add(new Encomenda(encomendaID, data, hora, morada, telefone, email, estadoEncomenda, profileID));
            } catch (JSONException e) {
                throw new RuntimeException(e);
            }
        }
        return encomendas;
    }

    public static DetalhesEncomenda parserJsonDetalhesEncomenda(String response) {
        DetalhesEncomenda detalhesEncomendas = null;
        try {
            //detalhes da encomenda
            JSONObject responseJson = new JSONObject(response);
            JSONObject encomendaJson = responseJson.getJSONObject("encomenda");
            int encomendaID = encomendaJson.getInt("encomendaID");
            String data = encomendaJson.getString("data");
            String hora = encomendaJson.getString("hora");
            String morada = encomendaJson.getString("morada");
            int telefone = encomendaJson.getInt("telefone");
            String email = encomendaJson.getString("email");
            String estadoEncomenda = encomendaJson.getString("estadoEncomenda");
            int profileID = encomendaJson.getInt("profile_id");

            //produtos associados à encomenda
            JSONArray produtosJson = responseJson.getJSONArray("produtos");
            ArrayList<ProdutoDetalhes> produtos = new ArrayList<>();

            for (int j = 0; j < produtosJson.length(); j++) {
                JSONObject produtoJson = produtosJson.getJSONObject(j);
                String nomeProduto = produtoJson.getString("nomeProduto");
                String precoStr = produtoJson.getString("preco").replace(",", ".");
                float preco = Float.parseFloat(precoStr);
                int quantidade = produtoJson.getInt("quantidade");

                ProdutoDetalhes produto = new ProdutoDetalhes(nomeProduto, preco, quantidade);
                produtos.add(produto);
            }

            detalhesEncomendas = new DetalhesEncomenda(encomendaID, data, hora, morada, telefone, email, estadoEncomenda, profileID, produtos);
        } catch (JSONException e) {
            throw new RuntimeException(e);
        }

        return detalhesEncomendas;
    }

    public static boolean isConnectionInternet(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo ni = cm.getActiveNetworkInfo();
        return ni != null && ni.isConnectedOrConnecting();
    }
}
