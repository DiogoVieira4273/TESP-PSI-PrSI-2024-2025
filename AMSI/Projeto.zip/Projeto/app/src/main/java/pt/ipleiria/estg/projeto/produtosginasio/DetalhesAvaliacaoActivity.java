package pt.ipleiria.estg.projeto.produtosginasio;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;

import pt.ipleiria.estg.projeto.produtosginasio.modelo.Avaliacao;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.SingletonProdutosGinasio;

public class DetalhesAvaliacaoActivity extends AppCompatActivity {
    private int id;
    private String IP, AUTH_KEY;
    private Avaliacao avaliacao;
    private EditText etDescricaoAvaliacao;
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhes_avaliacao);
        setTitle("Detalhes Avaliação");

        id = getIntent().getIntExtra(AvaliacoesActivity.AvaliacaoID, 0);
        avaliacao = SingletonProdutosGinasio.getInstance(getApplicationContext()).getAvaliacao(id);

        sharedPreferences = getApplication().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);

        IP = sharedPreferences.getString("IP", "");
        AUTH_KEY = sharedPreferences.getString("auth_key", "");

        etDescricaoAvaliacao = findViewById(R.id.etDescricaoAvaliacao);

        carregarAvaliacao();
    }

    private void carregarAvaliacao() {
        etDescricaoAvaliacao.setText(avaliacao.getDescricao());
    }

    public void onClickAtualizarAvaliacao(View view) {
        SingletonProdutosGinasio.getInstance(getApplicationContext()).atualizarAvaliacaoAPI(getApplicationContext(), IP, AUTH_KEY, avaliacao.getId(), etDescricaoAvaliacao.getText().toString());
    }

    public void onClickApagarAvaliacao(View view) {
        SingletonProdutosGinasio.getInstance(getApplicationContext()).apagarAvaliacaoAPI(getApplicationContext(), IP, AUTH_KEY, avaliacao.getId());

        finish();
    }
}