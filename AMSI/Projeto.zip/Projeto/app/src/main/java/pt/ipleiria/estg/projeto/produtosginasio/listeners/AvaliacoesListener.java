package pt.ipleiria.estg.projeto.produtosginasio.listeners;

import java.util.ArrayList;

import pt.ipleiria.estg.projeto.produtosginasio.modelo.Avaliacao;

public interface AvaliacoesListener {
    void onRefreshAvaliacoes(ArrayList<Avaliacao> listaAvaliacoes);
}
