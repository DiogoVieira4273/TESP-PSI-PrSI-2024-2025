package pt.ipleiria.estg.projeto.produtosginasio.listeners;

import pt.ipleiria.estg.projeto.produtosginasio.modelo.DetalhesEncomenda;

public interface DetalhesEncomendaListener {
    void onRefreshDetalhes(DetalhesEncomenda detalhes);
}
