package pt.ipleiria.estg.projeto.produtosginasio;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Map;

import pt.ipleiria.estg.projeto.produtosginasio.listeners.UserProfileListener;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.SingletonProdutosGinasio;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.User;

public class PerfilActivity extends AppCompatActivity implements UserProfileListener {
    private TextView etUsername, etEmail, etPassword, etNif, etMorada, etTelefone;
    private String IP, AUTH_KEY;
    private User user;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);

        setTitle("Dados Perfil");

        etUsername = findViewById(R.id.etUsername);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        etNif = findViewById(R.id.etNif);
        etMorada = findViewById(R.id.etMorada);
        etTelefone = findViewById(R.id.etTelefone);

        sharedPreferences = getApplication().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);

        IP = sharedPreferences.getString("IP", "");
        AUTH_KEY = sharedPreferences.getString("auth_key", "");

        SingletonProdutosGinasio.getInstance(getApplicationContext()).getDadosuserprofileAPI(getApplicationContext(), IP, AUTH_KEY);
        SingletonProdutosGinasio.getInstance(getApplicationContext()).setUserProfileListener(this);

    }

    private void carregarDadosUser(Map<String, String> dadosUserProfile) {
        etUsername.setText(dadosUserProfile.get("username"));
        etEmail.setText(dadosUserProfile.get("email"));
        etNif.setText(dadosUserProfile.get("nif"));
        etMorada.setText(dadosUserProfile.get("morada"));
        etTelefone.setText(dadosUserProfile.get("telefone"));
    }

    @Override
    public void onRefreshDetalhes(Map<String, String> dadosUserProfile) {
        if (dadosUserProfile != null) {
            carregarDadosUser(dadosUserProfile);
        } else {
            //Caso os dados não tenham sido carregados corretamente
            Toast.makeText(this, "Erro ao carregar os dados do utilizador", Toast.LENGTH_SHORT).show();
        }
    }

    public void onClickAtualizarPerfil(View view) {
        sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);

        IP = sharedPreferences.getString("IP", "");

        String username = etUsername.getText().toString();
        String email = etEmail.getText().toString();
        String password = etPassword.getText().toString();
        int nif = Integer.parseInt(etNif.getText().toString());
        String morada = etMorada.getText().toString();
        int telefone = Integer.parseInt(etTelefone.getText().toString());

        if (etUsername.getText().toString().isEmpty()) {
            Toast.makeText(this, "Campo do username não preenchido", Toast.LENGTH_LONG).show();
            return;
        }
        if (etEmail.getText().toString().isEmpty()) {
            Toast.makeText(this, "Campo do email não preenchido", Toast.LENGTH_LONG).show();
            return;
        }
        if (etNif.getText().toString().isEmpty()) {
            Toast.makeText(this, "Campo do nif não preenchido", Toast.LENGTH_LONG).show();
            return;
        }
        if (etMorada.getText().toString().isEmpty()) {
            Toast.makeText(this, "Campo da morada não preenchido", Toast.LENGTH_LONG).show();
            return;
        }
        if (etTelefone.getText().toString().isEmpty()) {
            Toast.makeText(this, "Campo do telefone não preenchido", Toast.LENGTH_LONG).show();
            return;
        }

        user = new User(0, username, email, password, nif, morada, telefone);

        SingletonProdutosGinasio.getInstance(getApplicationContext()).ataulizarUserAPI(this, IP, AUTH_KEY, user);
    }

    @Override
    public void onValidateAtualizar(Context context) {
        Toast.makeText(this, "Concluido! \n A aplicação vai ser reiniciada.", Toast.LENGTH_LONG).show();
        sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
        editor = sharedPreferences.edit();
        editor.remove("auth_key");
        editor.remove("username");
        editor.remove("email");
        editor.remove("profile_id");
        editor.apply();

        Intent intent = new Intent(context, LoginActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);

        // Finalizar todas as atividades anteriores
        if (context instanceof Activity) {
            ((Activity) context).finishAffinity();
        }
    }
}