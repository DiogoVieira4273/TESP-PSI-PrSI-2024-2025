package pt.ipleiria.estg.projeto.produtosginasio.adaptadores;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import pt.ipleiria.estg.projeto.produtosginasio.R;
import pt.ipleiria.estg.projeto.produtosginasio.modelo.Compra;

public class HistoricoComprasAdaptador extends BaseAdapter {
    private Context context;
    private LayoutInflater inflater;
    private ArrayList<Compra> compras;

    public HistoricoComprasAdaptador(Context context, ArrayList<Compra> compras) {
        this.context = context;
        this.compras = compras;
    }

    @Override
    public int getCount() {
        return compras.size();
    }

    @Override
    public Object getItem(int i) {
        return compras.get(i);
    }

    @Override
    public long getItemId(int i) {
        return compras.get(i).getId();
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (inflater == null) {
            inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }

        if (view == null) {
            view = inflater.inflate(R.layout.item_historico_de_compras, null);
        }

        //para ir buscar um livro pela primeira vez
        //quando vai pela segunda vez, este pedaço de código não funciona
        HistoricoComprasAdaptador.ViewHolderLista viewHolder = (HistoricoComprasAdaptador.ViewHolderLista) view.getTag();
        if (viewHolder == null) {
            viewHolder = new HistoricoComprasAdaptador.ViewHolderLista(view);
            view.setTag(viewHolder);
        }

        //apresentar os produto(s) na vista
        viewHolder.update(compras.get(i));

        return view;
    }

    private class ViewHolderLista {
        private TextView tvData, tvHora;
        private ImageView imgCapa;

        public ViewHolderLista(View view) {
            tvData = view.findViewById(R.id.tvData);
            tvHora = view.findViewById(R.id.tvHora);
            imgCapa = view.findViewById(R.id.imgCapa);
        }

        public void update(Compra c) {
            tvData.setText(c.getDataEmissao() + "");
            tvHora.setText(c.getHoraEmissao() + "");
            imgCapa.setImageResource(R.drawable.ic_action_compra);
        }
    }
}