package pt.ipleiria.estg.projeto.produtosginasio;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.widget.ImageButton;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;

public class FavoritosActivity extends AppCompatActivity {
    private ImageButton btnLista, btnGrelha;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favoritos);

        setTitle("Favoritos");

        btnLista = findViewById(R.id.btnLista);
        btnGrelha = findViewById(R.id.btnGrelha);

        //verifica se o fragmento já está carregado ou não
        if (savedInstanceState == null) {
            // Se não, carrega o fragmento ListaFavoritosFragment por padrão
            loadFragment(new ListaFavoritosFragment());
        }

        //troca para o fragmento de lista favoritos
        btnLista.setOnClickListener(v -> loadFragment(new ListaFavoritosFragment()));

        //troca para o fragmento grelha favoritos
        btnGrelha.setOnClickListener(v -> loadFragment(new GrelhaFavoritosFragment()));
    }

    //carregar o o tipo de visualização de produtos pretendido
    private void loadFragment(Fragment fragment) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragmentView, fragment)
                .commit();
    }
}